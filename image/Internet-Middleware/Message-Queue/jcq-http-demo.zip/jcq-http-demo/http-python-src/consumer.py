# -*- coding:UTF-8 -*-
import hmac, hashlib, collections, base64, time, requests, datetime, random, json, sys

#_TOPIC, _CGI = '<xxx>', '<xxx>'

class JCQ():
    def __init__(self,ak,sk,url):
        self.access_key = ak #'<xxx>'
        self.secret_key = sk #'<xxx>'
        self.url = url + '/v1/messages' #'http://<xxx>.jdcloud.com:8080'
    '''
    end_point= 'http://<xxx>.jdcloud.com:8080'
    url = end_point + '/v1/messages'   # GET or POST
    ack_url = end_point + '/v1/ack'    # POST only
    '''

    def md5(self, content):
        b = bytes(content, 'utf-8')
        h = hashlib.new('md5')
        h.update(b)
        return h.hexdigest()

    def message2str(self, message):
        m = dict(message)  # deep copy
        m.update(m.get('properties', {}))
        m.pop('properties')
        od = collections.OrderedDict(sorted(m.items()))
        ms = '&'.join([k + '=' + str(v) for k, v in od.items()])
        return self.md5(ms)

    def get_sign_source(self, headers, params):
        d = {
            'accessKey': headers['accessKey'],
            'dateTime': headers['dateTime'],
        }
        d.update(params)
        if type(d.get('messages')) == list:
            d['messages'] = ','.join([self.message2str(m) for m in d['messages']])
        od = collections.OrderedDict(sorted(d.items()))
        return '&'.join([k + '=' + str(v) for k, v in od.items()])

    def get_signature(self, source):
        key = self.secret_key.encode('utf-8')
        source = source.encode('utf-8')
        digester = hmac.new(key, source, hashlib.sha1)
        signature = base64.standard_b64encode(digester.digest())
        return signature.decode('utf-8').strip()

    def get_headers(self):
        return {
            "Content-Type": "application/json",
            "accessKey": self.access_key,
            "dateTime": datetime.datetime.utcnow().isoformat().split('.')[0] + "Z",
        }
    
        
    def send(self, topic, msg_type, messages):
        headers = self.get_headers()
        body = {
            "topic": topic,
            "type": msg_type,
            "messages": messages,
        }

        # sign the headers+body
        headers["signature"] = self.get_signature(self.get_sign_source(headers, body))
        resp = requests.post(self.url, headers=headers, data=json.dumps(body))
        return resp.text

        
    def ack(self, topic, group_id, ack_index, ack_action="SUCCESS"):
        headers = self.get_headers()
        body = {
            "topic": topic,
            "consumerGroupId": group_id,
            "ackAction": ack_action,
            "ackIndex": ack_index,
        }

        # sign the headers+body
        headers["signature"] = self.get_signature(self.get_sign_source(headers, body))
        resp = requests.post(self.ack_url, headers=headers, data=json.dumps(body))
        return resp.text

    def get(self, topic, group_id, size=20, auto_ack=False):
        headers = self.get_headers()
        params = {
            "topic": topic,
            "consumerGroupId": group_id,
            "size": int(size),
            "ack": 'true'
        }
        headers["signature"] = self.get_signature(self.get_sign_source(headers, params))
        resp = requests.get(self.url, headers=headers, params=params)
        return resp.text



def test(ak,sk,topic,url,consumer_group_id):
    # send five messages
    j = JCQ(ak,sk,url)
    '''
    messages = []
    for ix in range(5):
        messages.append({
            'body': 'message-%d' % ix,
            'delaySeconds': 0,
            'tag': 'mytag',
            'properties': {str(random.randint(0, 100)): 'test'}
        })
    resp = j.send(topic, "NORMAL", messages)
    print('Sent 5 messages: ' + resp)


    # get back one message at a time with auto ack, 8 times
    '''
    datas = []
    start_time = int(time.time())
    while True:
        resp = j.get(topic, consumer_group_id, True)
        if json.loads(resp).get('result').get('messages'):
            #print('Got one message: ' + resp)
            messages = json.loads(resp).get('result').get('messages')
            for m in messages:
                print(json.loads(m.get('messageBody')).get('id'))
            #print(json.loads(json.loads(resp).get('result').get('messages')[0].get('messageBody')).get('id'))
                datas.append(int(json.loads(m.get('messageBody')).get('id')))
            start_time = int(time.time())
        else:
            pass
            #print('xxxxxx')

        #if len(datas) >= 10:
        if int(time.time()) - start_time >= 30:
            datas.sort()
            with open('x','w')as f:
                for i in datas:
                    f.write(str(i)+'\n')
            break
            
    '''
    #print('--- %d ----' % ix)
    #j = JCQ()
    resp = j.get(topic, consumer_group_id, True)
    if resp:
        print('Got one message: ' + resp)
    '''

if __name__ == '__main__':
    ak = sys.argv[1]
    sk = sys.argv[2]
    topic = sys.argv[3]
    url = sys.argv[4]
    consumer_group_id = sys.argv[5]
    test(ak,sk,topic,url,consumer_group_id)

