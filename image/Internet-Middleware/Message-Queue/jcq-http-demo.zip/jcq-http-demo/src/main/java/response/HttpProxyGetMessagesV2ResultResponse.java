package response;

import bean.MessageResultV2;


public class HttpProxyGetMessagesV2ResultResponse extends HttpProxyResultResponse<MessageResultV2> {

}
