package response;

import bean.SendMessageResult;


public class HttpProxySendMessagesResultResponse extends HttpProxyResultResponse<SendMessageResult> {
    @Override
    public String toString() {
        return super.toString();
    }
}
