package request;



public abstract class RequestParameters {

    private String dateTime;

//    protected boolean validate() {
//        return isDateTimeValid();
//    }
//
//    private boolean isDateTimeValid() {
//        ZonedDateTime zonedDateTime = TimeUtils.utcDateStringToZonedDateTime(getDateTime());
//        return zonedDateTime != null && zonedDateTime.isBefore(ZonedDateTime.now(ZoneOffset.UTC)) &&
//                zonedDateTime.plusSeconds(ConfigService.getInstance().getHttpProxyRequestTimeoutInSeconds()).isAfter(ZonedDateTime.now(ZoneOffset.UTC));
//    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }
}