package demo;

import request.SendMessageParameters;
import response.HttpProxyGetMessagesV2ResultResponse;
import response.HttpProxySendMessagesResultResponse;
import util.JCQHttpUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.TimeZone;

public class JCQHttpProcessor {


    private static final String Ak = "***************";
    private static final String Sk = "***************";
    private static final String topicName = "***************";
    private static final String consumerGroupId = "***************";
    private static final String endPoint = "jcq-shared-004.cn-north-1.jdcloud.com";

    public void sendMessage() throws Exception {
        SendMessageParameters sendMsgParas = new SendMessageParameters();
        SendMessageParameters.Message msg1 = sendMsgParas.new Message();
        HashMap<String, String> map1 = new HashMap<String, String>();
        map1.put("key1", "value1");
        msg1.setBody("this is https");
        msg1.setProperties(map1);

        ArrayList<SendMessageParameters.Message> msgs = new ArrayList<SendMessageParameters.Message>();
        msgs.add(msg1);
        sendMsgParas.setMessages(msgs);
        sendMsgParas.setTopic(topicName);
        sendMsgParas.setType("NORMAL");
        HttpProxySendMessagesResultResponse response = JCQHttpUtil.sendMessages(JCQHttpProcessor.Ak, JCQHttpProcessor.Sk, getUtcNow(), sendMsgParas, endPoint, "v2", null, true);
        System.out.println("response is " + response);
    }

    private void pullMessage() throws Exception {
        HttpProxyGetMessagesV2ResultResponse response = JCQHttpUtil.getMessages(JCQHttpProcessor.Ak, JCQHttpProcessor.Sk, getUtcNow(), topicName, consumerGroupId, 1, null, null, null, null, true, endPoint, "v2", null, true);
        System.out.println("response is " + response);
    }

   /* private void ackMessage() {
    }*/

    public static String getUtcNow(){
        java.text.SimpleDateFormat simpleDateFormat =new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return simpleDateFormat.format(Calendar.getInstance().getTime());
    }

    public static void main(String[] args) throws Exception {
        JCQHttpProcessor processor = new JCQHttpProcessor();
        processor.sendMessage();
        processor.pullMessage();
//        processor.ackMessage();
    }

}
