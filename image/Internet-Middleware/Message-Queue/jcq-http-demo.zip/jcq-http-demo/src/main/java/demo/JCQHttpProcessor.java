package demo;

import request.AckMessageParametersV2;
import request.GetMessageParameters;
import request.SendMessageParameters;
import response.HttpProxyGetMessagesV2ResultResponse;
import response.HttpProxyResultResponse;
import response.HttpProxySendMessagesResultResponse;
import util.JCQHttpUtil;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.TimeZone;

public class JCQHttpProcessor {


    private static final String Ak = "********************************";
    private static final String Sk = "********************************";
    private static final String topicName = "******";
    private static final String consumerGroupId = "******";
    private static final String endPoint = "jcq-internet-001-httpsrv-nlb-FI.jvessel-open-hb.jdcloud.com:8080";

    public void sendMessage() throws Exception {
        SendMessageParameters sendMsgParas = new SendMessageParameters();
        SendMessageParameters.Message msg1 = sendMsgParas.new Message();
        HashMap<String, String> map1 = new HashMap<>();
        map1.put("key1", "value1");
        msg1.setBody("this is https");
        msg1.setProperties(map1);

        ArrayList<SendMessageParameters.Message> msgs = new ArrayList<SendMessageParameters.Message>();
        msgs.add(msg1);
        sendMsgParas.setMessages(msgs);
        sendMsgParas.setTopic(topicName);
        sendMsgParas.setType("NORMAL");
        sendMsgParas.setDateTime(getUtcNow());
        HttpProxySendMessagesResultResponse response = JCQHttpUtil.sendMessages(JCQHttpProcessor.Ak, JCQHttpProcessor.Sk,  sendMsgParas, endPoint, null, false);
        System.out.println("response is " + response);
    }

    private void pullMessageAutoAck() throws Exception {
        GetMessageParameters getMsgParas = new GetMessageParameters();
        getMsgParas.setTopic(topicName);
        getMsgParas.setConsumerGroupId(consumerGroupId);
        getMsgParas.setSize(1);
        getMsgParas.setConsumerId(null);
        getMsgParas.setConsumeFromWhere(null);
        getMsgParas.setFilterExpressionType(null);
        getMsgParas.setFilterExpression(null);
        getMsgParas.setAck(true);
        getMsgParas.setDateTime(getUtcNow());

        HttpProxyGetMessagesV2ResultResponse response = JCQHttpUtil.getMessages(JCQHttpProcessor.Ak, JCQHttpProcessor.Sk, getMsgParas, endPoint, false, null, false);
        System.out.println("response is " + response);
    }

    private void pullMessageManualAck() throws Exception{
        GetMessageParameters getMsgParas = new GetMessageParameters();
        getMsgParas.setTopic(topicName);
        getMsgParas.setConsumerGroupId(consumerGroupId);
        getMsgParas.setSize(1);
        getMsgParas.setConsumerId(null);
        getMsgParas.setConsumeFromWhere(null);
        getMsgParas.setFilterExpressionType(null);
        getMsgParas.setFilterExpression(null);
        getMsgParas.setAck(false);
        getMsgParas.setDateTime(getUtcNow());
        HttpProxyGetMessagesV2ResultResponse response = JCQHttpUtil.getMessages(JCQHttpProcessor.Ak, JCQHttpProcessor.Sk, getMsgParas, endPoint, false, null, false);
        String ackIndex = response.getResult().getAckIndex();
        if(ackIndex != null){
            AckMessageParametersV2 ackParas = new AckMessageParametersV2();
            ackParas.setTopic(topicName);
            ackParas.setDateTime(getUtcNow());
            ackParas.setConsumerGroupId(consumerGroupId);
            ackParas.setAckAction("SUCCESS");
            ackParas.setAckIndex(ackIndex);
            HttpProxyResultResponse ackResponse = JCQHttpUtil.ack(JCQHttpProcessor.Ak, JCQHttpProcessor.Sk, ackParas, endPoint, null, false);
            System.out.println("ack response is " + ackResponse);
        }


    }

    public static String getUtcNow(){
        java.text.SimpleDateFormat simpleDateFormat =new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        simpleDateFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
        return simpleDateFormat.format(Calendar.getInstance().getTime());
    }

    public static void main(String[] args) throws Exception {
        JCQHttpProcessor processor = new JCQHttpProcessor();
        processor.sendMessage();
        processor.pullMessageAutoAck();
        processor.pullMessageManualAck();
    }

}
