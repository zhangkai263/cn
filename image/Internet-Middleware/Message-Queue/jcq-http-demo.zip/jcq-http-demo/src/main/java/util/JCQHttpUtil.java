package util;

import com.alibaba.fastjson.JSON;
import request.GetMessageParameters;
import request.SendMessageParameters;
import response.HttpProxyGetMessagesV2ResultResponse;
import response.HttpProxySendMessagesResultResponse;

public class JCQHttpUtil {

    public static HttpProxySendMessagesResultResponse sendMessages(String accessKey,String secretKey, String datetime,  SendMessageParameters sendMsgs, String httpProxy, String version, String accessToken, boolean bHttps) throws Exception {
        String sourceSign = RequestSignSourceGenerator.getSignSource(sendMsgs, accessKey, datetime, accessToken);
        String signature = SignUtils.signWithHmacSha1(sourceSign, secretKey);
        return sendMessages(sendMsgs, accessKey, signature, datetime, httpProxy, version, accessToken, bHttps);
    }

    public static HttpProxySendMessagesResultResponse sendMessages(SendMessageParameters sendMsgs, String accessKey, String signature, String datetime, String httpProxy, String version, String accessToken, boolean bHttps) throws Exception{
        String jsonStr = JSON.toJSONString(sendMsgs);
        String url = String.format("%s/%s/messages",GetWebSiteRootUrl(httpProxy, bHttps), version);
        String returnObj = HttpClientHelper.getInstance().doHttpProxyPost(url,jsonStr, accessKey, signature, datetime, accessToken);
        return JSON.parseObject(returnObj, HttpProxySendMessagesResultResponse.class);
    }


    public static HttpProxyGetMessagesV2ResultResponse getMessages(
            String accessKey,
            String secretKey,
            String datetime,
            String topic,
            String consumerGroupId,
            Integer size,
            String consumerId,
            String consumeFromWhere,
            String filterExpressionType,
            String filterExpression,
            Boolean ack,
            String httpProxy,
            String version,
            String accessToken,
            boolean bHttps) throws Exception {
        // String accessKey = ConfigHelper.getAccessKey();
        //  String datetime = getUtcNow();
        GetMessageParameters getMsgParas = new GetMessageParameters();
        getMsgParas.setTopic(topic);
        getMsgParas.setConsumerGroupId(consumerGroupId);
        getMsgParas.setSize(size);
        getMsgParas.setConsumerId(consumerId);
        getMsgParas.setConsumeFromWhere(consumeFromWhere);
        getMsgParas.setFilterExpressionType(filterExpressionType);
        getMsgParas.setFilterExpression(filterExpression);
        getMsgParas.setAck(ack);

        String sourceSign = RequestSignSourceGenerator.getSignSource(getMsgParas, accessKey, datetime, accessToken);
        String signature = SignUtils.signWithHmacSha1(sourceSign, secretKey);
        return getMessages2(accessKey, signature, topic, consumerGroupId,datetime, size, consumerId, consumeFromWhere, filterExpressionType, filterExpression,ack, httpProxy, false, version, accessToken, bHttps);
    }

    private static HttpProxyGetMessagesV2ResultResponse getMessages2(String accessKey,
                                                                    String signature,
                                                                    String topic,
                                                                    String consumerGroupId,
                                                                    String dateTime,
                                                                    Integer size,
                                                                    String consumerId,
                                                                    String consumeFromWhere,
                                                                    String filterExpressionType,
                                                                    String filterExpression,
                                                                    Boolean ack,
                                                                    String httpProxy,
                                                                    boolean removeIfEmpty,
                                                                    String version,
                                                                    String accessToken,
                                                                    boolean bHttps
    ) throws Exception {
        // String httpProxy = GatewayAPIHelper.getGatewayAPIHelper().getHttpProxyAddress(topic);
        String url = String.format("%s/%s/messages/?", GetWebSiteRootUrl(httpProxy, bHttps), version);
        StringBuilder sb = new StringBuilder();
        sb.append(url);
        sb.append(String.format("topic=%s&", topic));
        sb.append(String.format("consumerGroupId=%s&", consumerGroupId));
        if (size != null) {
            sb.append(String.format("size=%s&", size));
        }
        if(removeIfEmpty)
        {
            sb.append(String.format("consumerId=%s&", consumerId));
            sb.append(String.format("consumeFromWhere=%s&", consumeFromWhere));
            sb.append(String.format("filterExpressionType=%s&", filterExpressionType));
            sb.append(String.format("filterExpression=%s&", filterExpression));
        }
        else {
            if (consumerId != null && !consumerId.isEmpty()) {
                sb.append(String.format("consumerId=%s&", consumerId));
            }
            if (consumeFromWhere != null && !consumeFromWhere.isEmpty()) {
                sb.append(String.format("consumeFromWhere=%s&", consumeFromWhere));
            }
            if (filterExpressionType != null && !filterExpressionType.isEmpty()) {
                sb.append(String.format("filterExpressionType=%s&", filterExpressionType));
            }
            if (filterExpression != null && !filterExpression.isEmpty()) {
                sb.append(String.format("filterExpression=%s&", filterExpression));
            }
        }

        sb.append(String.format("ack=%s", ack.toString()));
        return getMessages(sb.toString(), accessKey, signature, dateTime, accessToken);
    }

    private static HttpProxyGetMessagesV2ResultResponse getMessages(String url, String accessKey, String signature, String datetime, String accessToken) throws Exception{
        String jsonString = HttpClientHelper.getInstance().doHttpProxyGet(url, accessKey, datetime,signature, accessToken);
        return JSON.parseObject(jsonString, HttpProxyGetMessagesV2ResultResponse.class);
    }




    public static String GetWebSiteRootUrl(String httpProxy, boolean bHttps){
        if(bHttps){
            return String.format("https://%s", httpProxy);
        }
        return String.format("http://%s", httpProxy);
    }

}
