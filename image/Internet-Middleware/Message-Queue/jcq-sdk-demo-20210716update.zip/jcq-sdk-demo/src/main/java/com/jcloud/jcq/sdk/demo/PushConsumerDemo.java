package com.jcloud.jcq.sdk.demo;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.client.consumer.ConsumeResult;
import com.jcloud.jcq.client.consumer.MessageListener;
import com.jcloud.jcq.common.consumer.ConsumeFromWhere;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.JCQClientFactory;
import com.jcloud.jcq.sdk.auth.UserCredential;
import com.jcloud.jcq.sdk.consumer.Consumer;
import com.jcloud.jcq.sdk.consumer.ConsumerConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * 消费者 demo.
 * @ date 2018-05-17
 */
public class PushConsumerDemo {
    private static final Logger logger = LoggerFactory.getLogger(PushConsumerDemo.class);

    private static Consumer buildConsumer(String consumeGroup) throws ClientException {
        // 创建消息consumer, 普通及全局顺序消息都适用
        UserCredential userCredential = new UserCredential(EnvConstants.ACCESS_KEY, EnvConstants.SECRET_KEY);
        ConsumerConfig consumerConfig = ConsumerConfig.builder()
                .consumerGroupId(consumeGroup)
                .metaServerAddress(EnvConstants.META_SERVER_ADDRESS)
                .enableMessageTrace(true)                           //启用消息轨迹, 默认关闭
                .defaultConsumePosition(ConsumeFromWhere.HEAD)      //从哪里开始消费？ConsumeFromWhere.HEAD，ConsumeFromWhere.TAIL，默认值是HEAD。这个参数仅在第一次消费是起作用
                .consumePoolCoreSize(4)                             //JCQ是异步消费逻辑，推给客户端的消息。会交由消费线程池处理，这里指消费线程池的大小，默认值是4
                .consumeMaxRetryTimes(3)                            //自动消费重试次数，JCQ是异步消费逻辑，推给客户端的消息，交由消费线程池消费。默认值是3
                .maxBatchSizePerPush(32)                            //服务端一批推送的消息数，默认是32
                .messageBufferSize(1024)                            //客户端消费线程池队列数，从推送到消费之间能缓存多少个请求，默认值是1024
                .ackPoolCoreSize(2)                                 //ACK也是异步的，这里指回ACK请求的线程池的线程数量，默认值是2
                .ackBufferSize(1024)                                //ACK 线程池队列数，默认值是1024
                .build();
        return JCQClientFactory.getInstance().createConsumer(userCredential, consumerConfig);
    }

    public static void main(String[] args) throws Exception {

        final Consumer consumer = buildConsumer(EnvConstants.CONSUMER_GROUP);
        consumer.subscribeTopic(EnvConstants.TOPIC, new MessageListener() {
                    @Override
                    public ConsumeResult consumeMessages(List<Message> list) {
                        logger.info("received messages:{}", list);
                        if(DBMockUtil.insert(list)){
                            return ConsumeResult.SUCCESS;
                        }else{
                            return ConsumeResult.FAILED;
                        }
                    }
                },
                null);
        // 开启consumer,开始消费
        consumer.start();
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    consumer.shutdown();
                } catch (ClientException e) {
                    e.printStackTrace();
                }
            }
        }));

    }




}
