package demo.consumer;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.client.consumer.ConsumeResult;
import com.jcloud.jcq.client.consumer.MessageListener;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.consumer.Consumer;
import demo.DBMockUtil;
import demo.env.EnvConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

/**
 * 消费者 demo.
 *
 * @ date 2018-05-17
 */
public class PushConsumerDemo {
    private static final Logger logger = LoggerFactory.getLogger(PushConsumerDemo.class);

    public static void main(String[] args) throws Exception {
        // 从context中获取消费者bean （对于生命周期由spring管理的对象，比如controller、service等, 要使用consumer bean, 直接注入即可)
        final Consumer consumer = (Consumer) new ClassPathXmlApplicationContext("push-consumer.xml").getBean("consumer");
        consumer.subscribeTopic(EnvConstants.TOPIC, new MessageListener() {
                    @Override
                    public ConsumeResult consumeMessages(List<Message> list) {
                        logger.info("received messages:{}", list);
                        if(DBMockUtil.insert(list)){
                            return ConsumeResult.SUCCESS;
                        }else{
                            return ConsumeResult.FAILED;
                        }
                    }
                },
                null);
        // 开启consumer,开始消费
        consumer.start();
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    consumer.shutdown();
                } catch (ClientException e) {
                    e.printStackTrace();
                }
            }
        }));
    }
}
