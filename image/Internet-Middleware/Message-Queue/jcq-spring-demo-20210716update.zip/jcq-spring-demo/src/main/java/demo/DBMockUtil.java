package demo;

import com.jcloud.jcq.protocol.Message;

import java.util.List;

/**
 *
 * @ date 2021/6/22
 */
public class DBMockUtil {

    private DBMockUtil(){

    }

    public static boolean insert(List<Message> msgList){
        return true;
    }

    public static boolean insert(Message msg){
        return true;
    }
}
