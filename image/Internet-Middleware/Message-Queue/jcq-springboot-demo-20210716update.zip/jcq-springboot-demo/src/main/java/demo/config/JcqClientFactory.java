package demo.config;

import com.jcloud.jcq.sdk.JCQClientFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class JcqClientFactory {
    @Bean
    JCQClientFactory getJcqClientFactory() {
        return JCQClientFactory.getInstance();
    }
}
