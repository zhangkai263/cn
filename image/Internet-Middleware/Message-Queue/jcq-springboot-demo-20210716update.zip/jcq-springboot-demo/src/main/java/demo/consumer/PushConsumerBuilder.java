package demo.consumer;


import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.common.consumer.ConsumeFromWhere;
import com.jcloud.jcq.sdk.JCQClientFactory;
import com.jcloud.jcq.sdk.auth.UserCredential;
import com.jcloud.jcq.sdk.consumer.Consumer;
import com.jcloud.jcq.sdk.consumer.ConsumerConfig;
import demo.config.JcqConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PushConsumerBuilder {

    @Autowired
    private JcqConfig jcqConfig;

    @Autowired
    private JCQClientFactory jcqClientFactory;

    @Bean
    Consumer buildPushConsumer () throws ClientException {
        UserCredential userCredential =
                new UserCredential(jcqConfig.getAccessKey(), jcqConfig.getSecretKey());
        ConsumerConfig consumerConfig = ConsumerConfig.builder()
                .consumerGroupId(jcqConfig.getGroupId())
                .metaServerAddress(jcqConfig.getMetaSrvAddr())
                .enableMessageTrace(true)                           //启用消息轨迹, 默认关闭
                .defaultConsumePosition(ConsumeFromWhere.HEAD)      //从哪里开始消费？ConsumeFromWhere.HEAD，ConsumeFromWhere.TAIL，默认值是HEAD。这个参数仅在第一次消费是起作用
                .consumePoolCoreSize(4)                             //JCQ是异步消费逻辑，推给客户端的消息。会交由消费线程池处理，这里指消费线程池的大小，默认值是4
                .consumeMaxRetryTimes(3)                            //自动消费重试次数，JCQ是异步消费逻辑，推给客户端的消息，交由消费线程池消费。默认值是3
                .maxBatchSizePerPush(32)                            //服务端一批推送的消息数，默认是32
                .messageBufferSize(1024)                            //客户端消费线程池队列数，从推送到消费之间能缓存多少个请求，默认值是1024
                .ackPoolCoreSize(2)                                 //ACK也是异步的，这里指回ACK请求的线程池的线程数量，默认值是2
                .ackBufferSize(1024)                                //ACK 线程池队列数，默认值是1024
                .build();
        return jcqClientFactory.createConsumer(userCredential, consumerConfig);
    }

}
