package demo.producer;


import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.sdk.JCQClientFactory;
import com.jcloud.jcq.sdk.auth.UserCredential;
import com.jcloud.jcq.sdk.producer.GlobalOrderProducer;
import com.jcloud.jcq.sdk.producer.ProducerConfig;
import demo.config.JcqConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GlobalProducerBuilder {

    @Autowired
    private JcqConfig jcqConfig;

    @Autowired
    private JCQClientFactory jcqClientFactory;

    @Bean(initMethod = "start", destroyMethod = "shutdown")
    GlobalOrderProducer buildGlobalProducer () throws ClientException {
        UserCredential userCredential =
                new UserCredential(jcqConfig.getAccessKey(), jcqConfig.getSecretKey());
        ProducerConfig producerConfig = ProducerConfig.builder()
                .metaServerAddress(jcqConfig.getMetaSrvAddr()) //接入点地址
                .enableMessageTrace(true)       //启用消息轨迹，默认关闭
                .enableCompress(true)           //是否开启压缩, 消息Body >= 4KB 时启用zip压缩； 默认是开启的
                .maxRetryTimes(3)               //自动重试次数，默认是3次
                .build();
        return  jcqClientFactory.createGlobalOrderProducer(userCredential, producerConfig);
    }

}
