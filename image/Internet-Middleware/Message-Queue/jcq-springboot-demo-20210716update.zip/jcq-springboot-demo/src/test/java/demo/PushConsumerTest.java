package demo;


import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.client.consumer.ConsumeResult;
import com.jcloud.jcq.sdk.consumer.Consumer;
import demo.config.JcqConfig;
import org.junit.After;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class PushConsumerTest {
    private static final Logger logger = LoggerFactory.getLogger(PushConsumerTest.class);

    @Autowired
    private Consumer consumer;

    @Autowired
    private JcqConfig jcqConfig;

    @After
    public void afterMethod() throws Exception {
        consumer.shutdown();
    }

    @Test
    public void testPushConsumer() throws Exception {
        consumer.subscribeTopic(jcqConfig.getTopic(), (list) ->{
                        logger.info("received messages:{}", list);
                        return ConsumeResult.SUCCESS;
                    },
                null);
        // 开启consumer,开始消费

        try {
            consumer.start();
        } catch (ClientException e) {
            e.printStackTrace();
        }

        // 消费3秒后自动关闭consumer
        Thread.sleep(3000);
    }
}
