package demo;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.common.message.AckAction;
import com.jcloud.jcq.common.utils.StringUtils;
import com.jcloud.jcq.sdk.consumer.PullConsumer;
import com.jcloud.jcq.sdk.consumer.model.AckResult;
import com.jcloud.jcq.sdk.consumer.model.PullResult;
import com.jcloud.jcq.sdk.producer.model.ResultCode;
import demo.config.JcqConfig;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class PullConsumerTest {
    private static final Logger logger = LoggerFactory.getLogger(PullConsumerTest.class);

    @Autowired
    private PullConsumer pullConsumer;

    @Autowired
    private JcqConfig jcqConfig;

    @Test
    public void testPullConsumer() throws Exception {
        // 开启consumer,开始消费
        pullConsumer.start();
        for (int i = 0; i < 5; i++){
            try {
                // 同步拉取消息. 更多测试场景请参考jcq-spring-demo或jcq-sdk-demo.
                pullMessageSync();
            }catch (ClientException e){
                logger.error("there some thing happen ", e);
            }
            Thread.sleep(200);
        }
    }
    private  void pullMessageSync() throws ClientException {
        PullResult pullResult = pullConsumer.pullMessage(jcqConfig.getTopic(), null);
        processPullResult(pullResult);
    }

    private void processPullResult(PullResult pullResult) throws ClientException {
        if(ResultCode.SUCCESS != pullResult.getResultCode()){
            logger.warn("pull request failed, pull result is  {}", pullResult);
            return;
        }
        if(StringUtils.isEmpty(pullResult.getAckIndex()) || pullResult.getMessages() == null){
            logger.info("there is no message.");
            return;
        }
        String ackIndex = pullResult.getAckIndex();
        logger.info("Sync pullResult.resultCode:{}, pullResult. ackIndex:{}, pullResult.messages:{}",
                pullResult.getResultCode(), pullResult.getAckIndex(), pullResult.getMessages());

        //根据业务代码执行情况，设置返回值
        AckAction ackAction = AckAction.SUCCESS;

        AckResult ackResult = pullConsumer.ackMessage(jcqConfig.getTopic(), ackIndex, ackAction);
        processAckResult(ackIndex, ackAction, ackResult);
    }

    private void processAckResult(String ackIndex, AckAction ackAction, AckResult ackResult) {
        logger.info("Sync ackResult:{}", ackResult.getResultCode());
        if(ResultCode.SUCCESS != ackResult.getResultCode() && ackAction == AckAction.SUCCESS){
            //再次发送Ack，避免消息重复
            try {
                ackResult = pullConsumer.ackMessage(jcqConfig.getTopic(), ackIndex, ackAction);
                if(ackResult.getResultCode() != ResultCode.SUCCESS){
                    logger.warn("when retry ack for  topic {}, at ack Index {}, action {}, " +
                        "failed or ack already please confirm", jcqConfig.getTopic(), ackIndex, ackAction);
                }
            } catch (ClientException e) {
                logger.warn("when retry ack exception", e);
            }
        }
    }
}
