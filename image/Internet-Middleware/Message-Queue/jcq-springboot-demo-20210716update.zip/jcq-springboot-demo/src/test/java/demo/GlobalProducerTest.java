package demo;


import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.producer.GlobalOrderProducer;
import com.jcloud.jcq.sdk.producer.model.SendBatchResult;
import com.jcloud.jcq.sdk.producer.model.SendResult;
import demo.config.JcqConfig;
import demo.utils.ResponseCheckUtil;
import org.junit.*;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Arrays;

@RunWith(SpringRunner.class)
@SpringBootTest
public class GlobalProducerTest {
    private static final Logger logger = LoggerFactory.getLogger(GlobalProducerTest.class);
    private static final String SEND_MSG_RESPONSE_EXPRESSION = "send result: messageId:{}, resultCode:{}";
    private static final String SEND_FAILED_LOG_EXPRESSION = "send failed, and backup message {} failed";


    @Autowired
    private GlobalOrderProducer producer;

    @Autowired
    private JcqConfig jcqConfig;

    @Test
    public void testSendGlobalOrderMsg() throws ClientException{
        producer.start();
        try {
            sendSingle();
            //sendBatch();
        } catch (Exception e) {
            logger.info("there is some error happen, ", e);
        } finally {
            producer.shutdown();
        }
    }

    public void sendSingle() throws ClientException {
        Message message = new Message();
        message.setTopic(jcqConfig.getOrderTopic());
        message.setBody((jcqConfig.getMESSAGE_BODY()).getBytes());
        SendResult sendResult = producer.sendMessage(message);
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageId(), sendResult.getResultCode());
        if (ResponseCheckUtil.isResponseFailed(sendResult)) {
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }

    public void sendBatch() throws ClientException {
        Message message = new Message();
        message.setTopic(jcqConfig.getOrderTopic());
        message.setBody((jcqConfig.getMESSAGE_BODY()).getBytes());
        Message message1 = new Message();
        message1.setTopic(jcqConfig.getOrderTopic());
        message1.setBody((jcqConfig.getMESSAGE_BODY()).getBytes());
        SendBatchResult sendResult =  producer.sendBatchMessage(Arrays.asList(message, message1));
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageIds(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }
}
