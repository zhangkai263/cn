package demo.env;

/**
 * 环境常量定义
 * @ date 2021/6/21
 */
public class EnvConstants {

    private EnvConstants(){

    }
    /**
     * topic名称
     */
    public static final String TOPIC = "替换成普通Topic名称";

    public static final String FIFO_TOPIC = "替换成顺序Topic名称";

    public static final String MESSAGE_BODY = "testMessageBody";


}
