package demo.consumer;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.common.message.AckAction;
import com.jcloud.jcq.common.utils.StringUtils;
import com.jcloud.jcq.sdk.consumer.PullConsumer;
import com.jcloud.jcq.sdk.consumer.async.AsyncAckCallback;
import com.jcloud.jcq.sdk.consumer.async.AsyncPullCallback;
import com.jcloud.jcq.sdk.consumer.model.AckResult;
import com.jcloud.jcq.sdk.consumer.model.PullResult;
import com.jcloud.jcq.sdk.producer.model.ResultCode;
import demo.DBMockUtil;
import demo.env.EnvConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.concurrent.atomic.AtomicReference;

/**
 * 拉取型消费者 demo.
 *
 * @ date 2018-05-17
 */
public class PullConsumerDemo {
    private static final Logger logger = LoggerFactory.getLogger(PullConsumerDemo.class);
    public static void main(String[] args) throws Exception {
        // 从context中获取消费者bean （对于生命周期由spring管理的对象，比如controller、service等, 要使用consumer bean, 直接注入即可)
        final PullConsumer pullConsumer = (PullConsumer) new ClassPathXmlApplicationContext("pull-consumer.xml").getBean("pullConsumer");

        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    pullConsumer.shutdown();
                } catch (ClientException e) {
                    e.printStackTrace();
                }
            }
        }));
        while (true){
            try {
                pullMessageSync(pullConsumer);
                /*pullMessageAsync(pullConsumer);
                pullMessageAckASync(pullConsumer);*/
                /*Thread.sleep(1000);*/
            }catch (ClientException e){
                logger.error("there some thing happen ", e);
            }
        }
    }

    private static void pullMessageSync(PullConsumer pullConsumer) throws ClientException {
        PullResult pullResult = pullConsumer.pullMessage(EnvConstants.TOPIC, null);
        processPullResult(pullConsumer, pullResult);
    }

    private static void pullMessageAsync(final PullConsumer pullConsumer) throws ClientException{
        // 异步拉取消息,当需要指定tag作为过滤条件时，第二个参数填充具体的filterExpression
        pullConsumer.pullMessageAsync(EnvConstants.TOPIC, null, new AsyncPullCallback() {
            @Override
            public void onResult(PullResult pullResult) {
                try {
                    processPullResult(pullConsumer, pullResult);
                } catch (ClientException e) {
                    logger.warn("there some error happened ", e);
                }
            }

            @Override
            public void onException(Throwable throwable) {
                logger.error("async pull message error ", throwable);
            }
        });

    }

    private static void pullMessageAckASync(final PullConsumer pullConsumer) throws ClientException {
        PullResult pullResult = pullConsumer.pullMessage(EnvConstants.TOPIC, null);
        if(ResultCode.SUCCESS != pullResult.getResultCode()){
            logger.warn("pull request failed, pull result is  {}", pullResult);
            return;
        }
        if(StringUtils.isEmpty(pullResult.getAckIndex()) || pullResult.getMessages() == null){
            logger.info("there is no message. pull result is {}", pullResult);
            return;
        }

        final String ackIndex = pullResult.getAckIndex();
        logger.info("Sync pullResult.resultCode:{}, pullResult.ackIndex:{}, pullResult.messages:{}",
                pullResult.getResultCode(), pullResult.getAckIndex(), pullResult.getMessages());

        final AtomicReference<AckAction> ackAction = new AtomicReference<>(AckAction.CONSUME_FAILED);
        if(DBMockUtil.insert(pullResult.getMessages())){
            ackAction.set(AckAction.SUCCESS);
        }
        pullConsumer.ackMessageAsync(EnvConstants.TOPIC, ackIndex, ackAction.get(), new AsyncAckCallback() {
            @Override
            public void onResult(AckResult ackResult) {
                processAckResult(pullConsumer, ackIndex, ackAction.get(), ackResult);
            }

            @Override
            public void onException(Throwable throwable) {
                logger.error("async pull message error ", throwable);
            }
        });
    }

    private static void processPullResult(PullConsumer pullConsumer, PullResult pullResult) throws ClientException {
        if(ResultCode.SUCCESS != pullResult.getResultCode()){
            logger.warn("pull request failed, pull result is  {}", pullResult);
            return;
        }
        if(StringUtils.isEmpty(pullResult.getAckIndex()) || pullResult.getMessages() == null){
            logger.info("there is no message.");
            return;
        }
        String ackIndex = pullResult.getAckIndex();
        logger.info("Sync pullResult.resultCode:{}, pullResult. ackIndex:{}, pullResult.messages:{}",
                pullResult.getResultCode(), pullResult.getAckIndex(), pullResult.getMessages());

        AckAction ackAction = AckAction.CONSUME_FAILED;
        //模拟业务代码
        if(DBMockUtil.insert(pullResult.getMessages())){
            ackAction = AckAction.SUCCESS;
        }
        AckResult ackResult = pullConsumer.ackMessage(EnvConstants.TOPIC, ackIndex, ackAction);
        processAckResult(pullConsumer, ackIndex, ackAction, ackResult);
    }

    private static void processAckResult(PullConsumer pullConsumer, String ackIndex, AckAction ackAction, AckResult ackResult) {
        logger.info("Sync ackResult:{}", ackResult.getResultCode());
        if(ResultCode.SUCCESS != ackResult.getResultCode() && ackAction == AckAction.SUCCESS){
            //再次发送Ack，避免消息重复
            try {
                ackResult = pullConsumer.ackMessage(EnvConstants.TOPIC, ackIndex, ackAction);
                if(ackResult.getResultCode() != ResultCode.SUCCESS){
                    logger.warn("when retry ack for  topic {}, at ack Index {}, action {}, failed or ack already ,please confirm",
                            EnvConstants.TOPIC, ackIndex, ackAction);
                }
            } catch (ClientException e) {
                logger.warn("when retry ack exception", e);
            }
        }
    }

}
