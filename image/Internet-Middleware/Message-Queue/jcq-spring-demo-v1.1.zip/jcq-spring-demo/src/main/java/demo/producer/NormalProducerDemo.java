package demo.producer;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.common.constants.MessageConstants;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.producer.Producer;
import com.jcloud.jcq.sdk.producer.async.AsyncSendBatchCallback;
import com.jcloud.jcq.sdk.producer.async.AsyncSendCallback;
import com.jcloud.jcq.sdk.producer.model.SendBatchResult;
import com.jcloud.jcq.sdk.producer.model.SendResult;
import demo.DBMockUtil;
import demo.ResponseCheckUtil;
import demo.env.EnvConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Arrays;
import java.util.List;

/**
 * 普通消息生产者 demo.
 *
 * @ date 2018-05-17
 */
public class NormalProducerDemo {
    private static final Logger logger = LoggerFactory.getLogger(NormalProducerDemo.class);
    private static final String SEND_MSG_RESPONSE_EXPRESSION = "send result: messageId:{}, resultCode:{}";
    private static final String SEND_FAILED_LOG_EXPRESSION = "send failed, and backup message {} failed";

    public static void main(String[] args) throws Exception {
        // 从context中获取生产者bean （对于生命周期由spring管理的对象，比如controller、service等, 要使用producer bean, 直接注入即可)
        Producer producer = (Producer) new ClassPathXmlApplicationContext("normal-producer.xml").getBean("producer");
        // 开启producer
        producer.start();
        try{
            //发送单条
            sendSingleSync(producer);
/*
            //发送批量
            sendBatchSync(producer);

            //发送批量，部分是延时消息, 不可用于顺序topic
            sendBatchWithDelay(producer);

            //发送批量, 带BusinessID，可以用于顺序topic
            sendBatchWithBusinessId(producer);

            //异步发送单条，不可用于顺序Topic
            sendSingleAsync(producer);

            //异步发送批量，不可用于顺序Topic
            sendBatchAsync(producer);*/
        }catch (Exception e){
            logger.info("there is some error happen, ", e);
        }finally {
            Thread.sleep(1000); //等待trace发送完成
            producer.shutdown();
        }
    }

    private static void sendSingleSync(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        SendResult sendResult = producer.sendMessage(message);
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageId(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }

    private static void sendBatchSync(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        //可以发送带Tag的消息，形如 "TAG1|TAG2"
        SendBatchResult sendResult = producer.sendBatchMessage(Arrays.asList(message, message2));
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageIds(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }

    private static void sendBatchWithBusinessId(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        //可以发送带BusinessID的消息，可以用来查询消息，可以重复,长度不超过128
        message2.getProperties().put(MessageConstants.PROPERTY_BUSINESS_ID, String.valueOf(1234));

        SendBatchResult sendResult = producer.sendBatchMessage(Arrays.asList(message, message2));
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageIds(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }

    private static void sendBatchWithDelay(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        //统一批次里消息，本条延迟5秒，5秒后才可以被消费者消费到
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        message2.getProperties().put(MessageConstants.PROPERTY_DELAY_TIME, String.valueOf(5));

        SendBatchResult sendResult = producer.sendBatchMessage(Arrays.asList(message, message2));
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageIds(), sendResult.getResultCode());
        processSendMessageResponse(message, sendResult);
    }

    private static void processSendMessageResponse(Message message, SendBatchResult sendResult) {
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }

    private static void sendSingleAsync(final Producer producer) throws ClientException {
        final Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        producer.sendMessageAsync(message, new AsyncSendCallback() {
            @Override
            public void onResult(SendResult sendResult) {
                logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageId(), sendResult.getResultCode());
                if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
                    logger.error(SEND_FAILED_LOG_EXPRESSION, message);
                }
            }
            @Override
            public void onException(Throwable throwable) {
                logger.info("send failed exception:", throwable);
                if(!DBMockUtil.insert(message)){
                    logger.error(SEND_FAILED_LOG_EXPRESSION, message);
                }
            }
        });
    }

    private static void sendBatchAsync(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        final List<Message> msgList = Arrays.asList(message, message2);
        producer.sendBatchMessageAsync(msgList, new AsyncSendBatchCallback() {
            @Override
            public void onResult(SendBatchResult sendBatchResult) {
                logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendBatchResult.getMessageIds(), sendBatchResult.getResultCode());
                if(ResponseCheckUtil.isResponseFailed(sendBatchResult) && !DBMockUtil.insert(msgList)){
                    logger.error(SEND_FAILED_LOG_EXPRESSION, msgList);
                }
            }
            @Override
            public void onException(Throwable throwable) {
                logger.info("send failed exception:", throwable);
                if(!DBMockUtil.insert(msgList)){
                    logger.error(SEND_FAILED_LOG_EXPRESSION, msgList);
                }
            }
        });
    }
}
