package demo.consumer;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.client.consumer.ConsumeResult;
import com.jcloud.jcq.client.consumer.MessageListener;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.consumer.Consumer;
import demo.DBMockUtil;
import demo.env.EnvConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.List;

/**
 * global FIFO push 消费者 demo. 每次固定消费1条消息.
 * 全局顺序topic 仅有一个partition，1000TPS，适用于要求严格顺序的业务
 * @ date 2021-10-09
 */
public class GlobalFIFOPushConsumerDemo {
    private static final Logger logger = LoggerFactory.getLogger(GlobalFIFOPushConsumerDemo.class);

    public static void main(String[] args) throws Exception {
        // 从context中获取消费者bean （对于生命周期由spring管理的对象，比如controller、service等, 要使用consumer bean, 直接注入即可)
        final Consumer consumer = (Consumer) new ClassPathXmlApplicationContext("global-fifo-push-consumer.xml").getBean("fifoConsumer");
        consumer.subscribeTopic(EnvConstants.FIFO_TOPIC, new MessageListener() {
                    @Override
                    public ConsumeResult consumeMessages(List<Message> list) {
                        logger.info("received messages:{}", list);
                        if(DBMockUtil.insert(list)){
                            return ConsumeResult.SUCCESS;
                        }else{
                            return ConsumeResult.FAILED;
                        }
                    }
                },
                null);
        // 开启consumer,开始消费
        consumer.start();
        Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    consumer.shutdown();
                } catch (ClientException e) {
                    e.printStackTrace();
                }
            }
        }));
    }
}
