package demo.producer;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.common.constants.MessageConstants;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.producer.GlobalOrderProducer;
import com.jcloud.jcq.sdk.producer.model.SendBatchResult;
import com.jcloud.jcq.sdk.producer.model.SendResult;
import demo.DBMockUtil;
import demo.ResponseCheckUtil;
import demo.env.EnvConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * 全局顺序消息生产者 demo.
 *
 * @ date 2018-05-17
 */
public class GlobalOrderProducerDemo {
    private static final Logger logger = LoggerFactory.getLogger(GlobalOrderProducerDemo.class);
    private static final String SEND_MSG_RESPONSE_EXPRESSION = "send result: messageId:{}, resultCode:{}";
    private static final String SEND_FAILED_LOG_EXPRESSION = "send failed, and backup message {} failed";

    public static void main(String[] args) throws Exception {
        // 从context中获取全局顺序消息生产者bean （对于生命周期由spring管理的对象，比如controller、service等, 要使用globalOrderProducer bean, 直接注入即可)
        GlobalOrderProducer globalOrderProducer = (GlobalOrderProducer) new ClassPathXmlApplicationContext("global-order-producer.xml").getBean("globalOrderProducer");
        globalOrderProducer.start();
        try{
            sendSingle(globalOrderProducer);
//            sendBatch(globalOrderProducer);
        }catch (Exception e){
            logger.info("there is some error happen, ", e);
        }finally {
            Thread.sleep(1000); //等待trace发送完成
            globalOrderProducer.shutdown();
        }
    }
    private static void sendBatch(GlobalOrderProducer globalOrderProducer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.FIFO_TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        Message message1 = new Message();
        message1.setTopic(EnvConstants.FIFO_TOPIC);
        message1.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        SendBatchResult sendResult =  globalOrderProducer.sendBatchMessage(Arrays.asList(message, message1));
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageIds(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }

    private static void sendSingle(GlobalOrderProducer globalOrderProducer) throws ClientException {
        // 创建message, 全局顺序消息不支持延迟投递属性设置
        Message message = new Message();
        message.setTopic(EnvConstants.FIFO_TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        Message message1 = new Message();
        message1.setTopic(EnvConstants.FIFO_TOPIC);
        message1.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        message1.getProperties().put(MessageConstants.PROPERTY_BUSINESS_ID, String.valueOf(1234));
        SendResult sendResult = globalOrderProducer.sendMessage(message);
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageId(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }
}
