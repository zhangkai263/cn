package demo;

import com.jcloud.jcq.protocol.Message;

import java.util.List;


public class DBMockUtil {

    private DBMockUtil(){

    }

    public static boolean insert(List<Message> msgList){
        return true;
    }

    public static boolean insert(Message msg){
        return true;
    }
}
