package com.jcloud.jcq.sdk.demo;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.common.constants.MessageConstants;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.JCQClientFactory;
import com.jcloud.jcq.sdk.auth.UserCredential;
import com.jcloud.jcq.sdk.producer.Producer;
import com.jcloud.jcq.sdk.producer.ProducerConfig;
import com.jcloud.jcq.sdk.producer.async.AsyncSendBatchCallback;
import com.jcloud.jcq.sdk.producer.async.AsyncSendCallback;
import com.jcloud.jcq.sdk.producer.model.SendBatchResult;
import com.jcloud.jcq.sdk.producer.model.SendResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;

/**
 * 普通消息生产者 demo.
 * @ date 2018-05-17
 */
public class NormalProducerDemo {
    private static final Logger logger = LoggerFactory.getLogger(NormalProducerDemo.class);
    private static final String SEND_FAILED_LOG_EXPRESSION = "send failed, and backup message {} failed";

    private static Producer buildJCQProducer() throws ClientException {
        UserCredential userCredential = new UserCredential(EnvConstants.ACCESS_KEY, EnvConstants.SECRET_KEY);
        ProducerConfig producerConfig = ProducerConfig.builder()
                .metaServerAddress(EnvConstants.META_SERVER_ADDRESS) //接入点地址
                .enableMessageTrace(true)       //启用消息轨迹，默认关闭
                .enableCompress(true)           //是否开启压缩, 消息Body >= 4KB 时启用zip压缩； 默认是开启的
                .maxRetryTimes(3)               //自动重试次数，默认是3次
                /*
                .remoteCallRetryWaitTime(100)   //服务端返回 THROUGHPUT_UP_TO_LIMIT，
                                                // ABNORMAL_ACCESS_RATE，
                                                // SEND_MESSAGE_TOO_FAST 等信息时，客户端等待间隔，毫秒数，默认值100 ms
                .refreshRouteRetryWaitTime(200) // 从meta server更新topic路由信息遇到限速，本地sleep的时长， 单位(ms), 默认值200
                 */
                .build();
        return JCQClientFactory.getInstance().createProducer(userCredential, producerConfig);
    }


    public static void main(String[] args) throws Exception {
        Producer producer = buildJCQProducer();
        // 开启producer
        producer.start();
        try{
            //发送单条
            sendSingleSync(producer);

            //发送批量
            sendBatchSync(producer);

            //发送批量，部分是延时消息, 不可用于顺序topic
            sendBatchWithDelay(producer);

            //发送批量, 带BusinessID，可以用于顺序topic
            sendBatchWithBusinessId(producer);

            //异步发送单条，不可用于顺序Topic
            sendSingleAsync(producer);

            //异步发送批量，不可用于顺序Topic
            sendBatchAsync(producer);
        }catch (Exception e){
            logger.info("there is some error happen, ", e);
        }finally {
            producer.shutdown();
        }
    }
    private static boolean sendSingleSync(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        SendResult sendResult = producer.sendMessage(message);
        if(ResponseCheckUtil.isResponseFailed(sendResult)){
            if(!DBMockUtil.insert(message)){
                logger.error(SEND_FAILED_LOG_EXPRESSION, message);
            }
            return false;
        }
        return true;
    }

    private static boolean sendBatchSync(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        //可以发送带Tag的消息，形如 "TAG1|TAG2"
        message2.getProperties().put(MessageConstants.PROPERTY_TAGS, EnvConstants.TAG);
        SendBatchResult sendResult = producer.sendBatchMessage(Arrays.asList(message, message2));

        if(ResponseCheckUtil.isResponseFailed(sendResult)){
            if(!DBMockUtil.insert(message)){
                logger.error(SEND_FAILED_LOG_EXPRESSION, message);
            }
            return false;
        }
        return true;
    }

    private static boolean sendBatchWithBusinessId(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        //可以发送带BusinessID的消息，可以用来查询消息，可以重复,长度不超过128
        message2.getProperties().put(MessageConstants.PROPERTY_BUSINESS_ID, String.valueOf(1234));

        SendBatchResult sendResult = producer.sendBatchMessage(Arrays.asList(message, message2));
        logger.info("sent : messageId:{}, resultCode:{}", sendResult.getMessageIds(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult)){
            if(!DBMockUtil.insert(message)){
                logger.error(SEND_FAILED_LOG_EXPRESSION, message);
            }
            return false;
        }
        return true;
    }

    private static boolean sendBatchWithDelay(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        //统一批次里消息，本条延迟5秒，5秒后才可以被消费者消费到
        message2.getProperties().put(MessageConstants.PROPERTY_DELAY_TIME, String.valueOf(5));
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        SendBatchResult sendResult = producer.sendBatchMessage(Arrays.asList(message, message2));
        logger.info("sent : messageId:{}, resultCode:{}", sendResult.getMessageIds(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult)){
            if(!DBMockUtil.insert(message)){
                logger.error(SEND_FAILED_LOG_EXPRESSION, message);
            }
            return false;
        }
        return true;
    }

    private static void sendSingleAsync(final Producer producer) throws ClientException {
        final Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        producer.sendMessageAsync(message, new AsyncSendCallback() {
            @Override
            public void onResult(SendResult sendResult) {
                logger.info("async sent: messageId:{}, resultCode:{}", sendResult.getMessageId(), sendResult.getResultCode());
                if(ResponseCheckUtil.isResponseFailed(sendResult)){
                    return;
                }
                BusinessOP.afterSendMessage(sendResult.getMessageId());
            }
            @Override
            public void onException(Throwable throwable) {
                logger.info("send failed exception:", throwable);
                if(!DBMockUtil.insert(message)){
                    logger.error(SEND_FAILED_LOG_EXPRESSION, message);
                }
            }
        });
    }

    private static void sendBatchAsync(Producer producer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        Message message2 = new Message();
        message2.setTopic(EnvConstants.TOPIC);
        message2.setBody((EnvConstants.MESSAGE_BODY).getBytes());

        final List<Message> msgList = Arrays.asList(message, message2);
        producer.sendBatchMessageAsync(msgList, new AsyncSendBatchCallback() {
            @Override
            public void onResult(SendBatchResult sendBatchResult) {
                logger.info("async sent: messageId:{}, resultCode:{}", sendBatchResult.getMessageIds(), sendBatchResult.getResultCode());
                if(ResponseCheckUtil.isResponseFailed(sendBatchResult)){
                    return;
                }
                BusinessOP.afterSendMessage(sendBatchResult.getMessageIds());
            }
            @Override
            public void onException(Throwable throwable) {
                logger.info("send failed exception:", throwable);
                if(!DBMockUtil.insert(msgList)){
                    logger.error(SEND_FAILED_LOG_EXPRESSION, msgList);
                }
            }
        });
    }
}
