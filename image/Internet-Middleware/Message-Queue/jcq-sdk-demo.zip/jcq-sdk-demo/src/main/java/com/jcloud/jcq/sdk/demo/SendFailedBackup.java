package com.jcloud.jcq.sdk.demo;

/**
 * @author tianjiyuan
 * @date 2021/6/23
 */
public class SendFailedBackup {
}
