package com.jcloud.jcq.sdk.demo;

/**
 * 环境常量定义
 * @ date 2021/6/21
 */
public class EnvConstants {

    private EnvConstants(){

    }

    public static final String ACCESS_KEY = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
    /**
     * 用户secretKey
     */
    public static final String SECRET_KEY = "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB";

    /**
     * 元数据服务器地址
     */
    public static final String META_SERVER_ADDRESS = "$ENDPOINTS";
    /**
     * topic名称
     */
    public static final String TOPIC = "topic_001";

    public static final String FIFO_TOPIC = "fifo_001";

    /**
     * 消费组
     */
    public static final String CONSUMER_GROUP = "CG_001";

    public static final String CONSUMER_GROUP_2 = "CG_002";


    public static final String TAG = "TAG1|TAG2";

    /**
     * 消息内容
     */

    public static final String MESSAGE_BODY = "this is message body";


}
