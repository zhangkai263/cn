package com.jcloud.jcq.sdk.demo;

import java.util.List;

/**
 *
 * @ date 2021/6/23
 */
public class BusinessOP {

    private BusinessOP(){

    }

    public static void afterSendMessage(String messageId){
        //do nothing
    }

    public static void afterSendMessage(List<String> messageId){
        //do nothing
    }
}
