package com.jcloud.jcq.sdk.demo;

import com.jcloud.jcq.sdk.producer.model.ResultCode;
import com.jcloud.jcq.sdk.producer.model.SendBatchResult;
import com.jcloud.jcq.sdk.producer.model.SendResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @ date 2021/6/23
 */
public class ResponseCheckUtil {
    private static final Logger logger = LoggerFactory.getLogger(ResponseCheckUtil.class);

    private ResponseCheckUtil(){

    }

    public static boolean isResponseFailed(SendResult sendResult) {
        return isResponseFailed(sendResult.getResultCode());
    }

    public static boolean isResponseFailed(SendBatchResult sendResult) {
        return isResponseFailed(sendResult.getResultCode());
    }

    private static boolean isResponseFailed(ResultCode resultCode) {
        if(ResultCode.FAILED == resultCode){
            logger.warn("send message failed");
            return true;
        }else{
            return false;
        }
    }
}
