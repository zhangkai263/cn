package com.jcloud.jcq.sdk.demo;

import com.jcloud.jcq.client.Exception.ClientException;
import com.jcloud.jcq.common.constants.MessageConstants;
import com.jcloud.jcq.protocol.Message;
import com.jcloud.jcq.sdk.JCQClientFactory;
import com.jcloud.jcq.sdk.auth.UserCredential;
import com.jcloud.jcq.sdk.producer.GlobalOrderProducer;
import com.jcloud.jcq.sdk.producer.ProducerConfig;
import com.jcloud.jcq.sdk.producer.model.SendBatchResult;
import com.jcloud.jcq.sdk.producer.model.SendResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;

/**
 * 全局顺序消息生产者 demo.
 * @ date 2018-05-17
 */
public class GlobalOrderProducerDemo {

    private static final Logger logger = LoggerFactory.getLogger(GlobalOrderProducerDemo.class);
    private static final String SEND_MSG_RESPONSE_EXPRESSION = "send result: messageId:{}, resultCode:{}";
    private static final String SEND_FAILED_LOG_EXPRESSION = "send failed, and backup message {} failed";


    private static GlobalOrderProducer buildJCQProducer() throws ClientException {
        // 创建全局顺序消息producer
        UserCredential userCredential = new UserCredential(EnvConstants.ACCESS_KEY, EnvConstants.SECRET_KEY);
        ProducerConfig producerConfig = ProducerConfig.builder()
                .metaServerAddress(EnvConstants.META_SERVER_ADDRESS) //接入点地址
                .enableMessageTrace(true)       //启用消息轨迹，默认关闭
                .enableCompress(true)           //是否开启压缩, 消息Body >= 4KB 时启用zip压缩； 默认是开启的
                .maxRetryTimes(3)               //自动重试次数，默认是3次。正常调用失败之后才算重试，所以最多调用次数是maxRetryTimes + 1。
                .build();
        return JCQClientFactory.getInstance().createGlobalOrderProducer(userCredential, producerConfig);
    }

    public static void main(String[] args) throws Exception {
        GlobalOrderProducer globalOrderProducer = buildJCQProducer();
        globalOrderProducer.start();
        try{
            sendSingle(globalOrderProducer);
//            sendBatch(globalOrderProducer);
        }catch (Exception e){
            logger.info("there is some error happen, ", e);
        }finally {
            globalOrderProducer.shutdown();
        }
    }

    private static void sendBatch(GlobalOrderProducer globalOrderProducer) throws ClientException {
        Message message = new Message();
        message.setTopic(EnvConstants.FIFO_TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        Message message1 = new Message();
        message1.setTopic(EnvConstants.FIFO_TOPIC);
        message1.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        SendBatchResult sendResult =  globalOrderProducer.sendBatchMessage(Arrays.asList(message, message1));
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageIds(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }

    private static void sendSingle(GlobalOrderProducer globalOrderProducer) throws ClientException {
        // 创建message, 全局顺序消息不支持延迟投递属性设置
        Message message = new Message();
        message.setTopic(EnvConstants.FIFO_TOPIC);
        message.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        Message message1 = new Message();
        message1.setTopic(EnvConstants.FIFO_TOPIC);
        message1.setBody((EnvConstants.MESSAGE_BODY).getBytes());
        message1.getProperties().put(MessageConstants.PROPERTY_BUSINESS_ID, String.valueOf(1234));
        SendResult sendResult = globalOrderProducer.sendMessage(message);
        logger.info(SEND_MSG_RESPONSE_EXPRESSION, sendResult.getMessageId(), sendResult.getResultCode());
        if(ResponseCheckUtil.isResponseFailed(sendResult) && !DBMockUtil.insert(message)){
            logger.error(SEND_FAILED_LOG_EXPRESSION, message);
        }
    }


}
