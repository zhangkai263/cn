package response;


import bean.MessageResult;


public class HttpProxyGetMessagesResultResponse extends HttpProxyResultResponse<MessageResult> {

}
