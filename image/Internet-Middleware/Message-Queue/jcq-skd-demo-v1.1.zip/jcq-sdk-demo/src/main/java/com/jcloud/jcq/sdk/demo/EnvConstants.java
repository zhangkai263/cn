package com.jcloud.jcq.sdk.demo;

/**
 * 环境常量定义
 * @ date 2021/6/21
 */
public class EnvConstants {

    private EnvConstants(){

    }

    /**
     * 用户accessKey
     */
    public static final String ACCESS_KEY = "替换成用户实际AccessKey";

    /**
     * 用户secretKey
     */
    public static final String SECRET_KEY = "替换成用户实际SecretKey";

    /**
     * 元数据服务器地址
     */
    public static final String META_SERVER_ADDRESS = "替换成topic的sdk接入点地址";
    /**
     * topic名称
     */
    public static final String TOPIC = "替换成普通Topic名称";

    public static final String FIFO_TOPIC = "替换成顺序Topic名称";

    /**
     * 消费组
     */
    public static final String CONSUMER_GROUP = "替换成订阅组1的consumeGroupId";


    /**
        收发消息使用的tag
     */
    public static final String TAG = "Tag";

    /**
     * 消息内容
     */

    public static final String MESSAGE_BODY = "testMessageBody";


}
