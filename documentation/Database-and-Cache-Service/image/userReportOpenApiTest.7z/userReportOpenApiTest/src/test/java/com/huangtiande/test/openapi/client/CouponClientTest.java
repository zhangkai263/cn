package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.coupon.client.CouponClient;
import com.jdcloud.sdk.service.coupon.model.DescribeBalanceValidateRequest;
import com.jdcloud.sdk.service.coupon.model.DescribeBalanceValidateResponse;
import org.junit.Test;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/11/15 14:59
 * @Email:huangtiande@jd.com
 */
public class CouponClientTest {

    private static CouponClient couponClient;

    static {

        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();

        couponClient = CouponClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        couponClient.setCustomHeader("x-jdcloud-erp", "huangtiande");
    }

    @Test
    public void describeBalanceValidateTest(){
        DescribeBalanceValidateRequest request = new DescribeBalanceValidateRequest();
        String pins = "6bcaa38a491341dcbc73";
        request.setPins(pins);
        request.setRegionId("cn-north-1");
        DescribeBalanceValidateResponse response = couponClient.describeBalanceValidate(request);
        System.out.println(new Gson().toJson(response));
    }
}
