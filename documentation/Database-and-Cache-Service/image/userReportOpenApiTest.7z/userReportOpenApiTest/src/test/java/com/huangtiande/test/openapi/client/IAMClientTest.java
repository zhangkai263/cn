package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.iam.client.IamClient;
import com.jdcloud.sdk.service.iam.model.AsyncSendEmailSmsRequest;
import com.jdcloud.sdk.service.iam.model.AsyncSendEmailSmsResponse;
import com.jdcloud.sdk.service.iam.model.EmailSmsInfo;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/11/6 11:06
 * @Email:huangtiande@jd.com
 */
public class IAMClientTest {

    private static IamClient iamClient;

    static {

        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();

        iamClient = IamClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build()) //使用HTTP
                .environment(ev)
                .build();
    }

    @Test
    public void syncSendEmailSmsTest(){
        AsyncSendEmailSmsRequest request = new AsyncSendEmailSmsRequest();
        EmailSmsInfo emailSmsInfo = new EmailSmsInfo();
        emailSmsInfo.setCreatePin("jcloud_sfRczzI");
        emailSmsInfo.setSendType(2);//2短信，1邮件
        List<String> phones = new ArrayList<String>();
        phones.add("15011393998");
        emailSmsInfo.setReceives(phones);
        emailSmsInfo.setTemplateId(5670);
        List<String> params = new ArrayList<String>();
        params.add("CDNvip");
        emailSmsInfo.setTemplateParam(params);
        emailSmsInfo.setSmsMessageSource("NOTICE_UC");//此处你使用 SendSmsSourceEnum 枚举方法
        request.setRegionId("cn-north-1");
        request.setEmailSmsInfoReqVo(emailSmsInfo);
        AsyncSendEmailSmsResponse response = iamClient.asyncSendEmailSms(request);
        System.out.println(new Gson().toJson(response));
    }
}
