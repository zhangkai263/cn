package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.developer.model.ArticleDetailRequest;
import com.jdcloud.sdk.service.developer.model.ArticleDetailResponse;
import com.jdcloud.sdk.service.portal.client.PortalClient;
import com.jdcloud.sdk.service.portal.model.*;
import org.junit.Test;

import java.util.ArrayList;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/12/6 15:04
 * @Email:huangtiande@jd.com
 */
public class PortalClientTest {

    private static PortalClient portalClient;

    static {

        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();

        portalClient = PortalClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        portalClient.setCustomHeader("x-jdcloud-pin", "jcloud_jRHaaPi");
    }

    @Test
    public void saveSearchDataTest(){
        SaveSearchDataRequest saveSearchDataRequest = new SaveSearchDataRequest();
        String title = "[管理-续费管理] 公网 IP";
        String url = "//renewal-console-stag.jdcloud.com/renew/ip";
        //公共部分
        saveSearchDataRequest.setRegionId("cn-north-1");
        saveSearchDataRequest.setIdentifying("console");
        saveSearchDataRequest.setClassification("console");
        saveSearchDataRequest.setStatus(0);
        saveSearchDataRequest.setStaticFileName(url);

        //中文部分
        saveSearchDataRequest.setTitle(title);
        saveSearchDataRequest.setContent("前往京东云控制台概览页，您可以根据实际需要进行操作配置。");
        saveSearchDataRequest.setLang("cn");
        saveSearchDataRequest.setFrom("控制台概览页云服务");
        SaveSearchDataResponse response = portalClient.saveSearchData(saveSearchDataRequest);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void deleteSearchDataTest(){
        DeleteSearchDataRequest deleteSearchDataRequest = new DeleteSearchDataRequest();
        String url = "///";
        deleteSearchDataRequest.setStaticFileName(url);
        deleteSearchDataRequest.setIdentifying("console");
        deleteSearchDataRequest.setRegionId("cn-north-1");
        deleteSearchDataRequest.setLang("cn");
        DeleteSearchDataResponse response = portalClient.deleteSearchData(deleteSearchDataRequest);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeNoticeListTest(){
        NoticeListRequest request = new NoticeListRequest();
        request.setLang("cn");
        request.setPageNum(1);
        request.setPageSize(100);
        request.setType(1);
        request.setRegionId("cn-north-1");
        NoticeListResponse response = portalClient.noticeList(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeQuerySensitiveFormInfoTest(){
        BatchQuerySensitiveFromInfoRequest request = new BatchQuerySensitiveFromInfoRequest();
        ArrayList list = new ArrayList<Long>();
        list.add(1445L);
        list.add(1446L);
        list.add(1447L);
        request.setIds(list);
        request.setRegionId("cn-north-1");
        BatchQuerySensitiveFromInfoResponse response = portalClient.batchQuerySensitiveFromInfo(request);
        System.out.println(new Gson().toJson(response));
    }

}
