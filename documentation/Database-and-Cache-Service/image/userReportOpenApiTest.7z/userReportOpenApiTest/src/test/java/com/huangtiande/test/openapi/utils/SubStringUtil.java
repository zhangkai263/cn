package com.huangtiande.test.openapi.utils;

import org.apache.commons.lang3.StringUtils;

import java.net.URLDecoder;

/**
 * Created by hushengbo on 2016/3/22.
 */
public class SubStringUtil {

    /***
     * 对国际手机号进行掩码处理
     * @param mobile 国际手机号
     * @return
     */
    public static String hiddenInternetMobile(String mobile){
        char[] chs = mobile.toCharArray();
        //区号正常显示,最后两位正常显示,其他显示为掩码
        int startIndex = mobile.indexOf("-")+1;
        for(int i=startIndex;i<mobile.length()-2;i++){
            chs[i] = '*';
        }
        return new String(chs);
    }

    /***
     * 截取前后字符
     * @param source  源字符串
     * @param preLen  前边要截取的长度 值必须大于0
     * @param sufLen  后边要截取的长度 值必须大于0
     * @return
     */
    public static String hiddenString(String source,int preLen, int sufLen,String replaceStr){
        if(source == null || StringUtils.isBlank(source)
                || preLen <= 0 || sufLen <= 0)
            return "";
        StringBuilder sb = new StringBuilder();
        //if((preLen + sufLen) >= source.length()) {
        if((preLen + sufLen) > source.length()) {
            return source+replaceStr;
        }else {
            sb.append(source.substring(0, preLen));
            sb.append(replaceStr);
            sb.append(source.substring(source.length() - sufLen));
            return sb.toString();
        }
    }

    /***
     * 截取前后字符
     * @param source  源字符串
     * @param preLen  前边要截取的长度 值必须大于0
     * @param sufLen  后边要截取的长度 值必须大于0
     * @return
     */
    public static String hiddenString2(String source,int preLen, int sufLen,String replaceStr){
        if(source == null || StringUtils.isBlank(source)
                || preLen <= 0 || sufLen <= 0)
            return "";
        StringBuilder sb = new StringBuilder();
        //if((preLen + sufLen) >= source.length()) {
        if((preLen + sufLen) > source.length()) {
            return source;
        }else {
            sb.append(source.substring(0, preLen));
            sb.append(replaceStr);
            sb.append(source.substring(source.length() - sufLen));
            return sb.toString();
        }
    }

    /***
     * 载一头，前边或后边
     * @param source
     * @param len
     * @param replaceStr 星号显示的位置前边还是后边
     * @return
     */
    public static String hiddenString(String source,int len,String replaceStr){
        if(source == null || StringUtils.isBlank(source)
                || len <= 0)
            return "";

        StringBuilder sb = new StringBuilder();
        if(len >= source.length()) {
            return source+replaceStr;
        }else {
            sb.append(source.substring(0, len));
            sb.append(replaceStr);
            return sb.toString();
        }
    }

    /***
     * 载一头，前边或后边
     * @param source
     * @param index
     * @return
     */
    public static String hiddenStringBefore(String source,int index,String replaceStr){
        if(source == null || StringUtils.isBlank(source)
                || index <= 0)
            return "";

        StringBuilder sb = new StringBuilder();
        if(index >= source.length()) {
            return replaceStr + source;
        }else {
            sb.append(replaceStr);
            sb.append(source.substring(index, source.length()));
            return sb.toString();
        }
    }

    public static String hiddenEmail(String source,String replaceStr){
        if(StringUtils.isBlank(source))
            return "";
        StringBuilder sb = new StringBuilder();
        if(source.indexOf("@") > 0){    //如果是邮箱只截邮箱名
            String[] email = source.split("@");
            if(email[0].length() <= 3){
                return sb.append(email[0]).append(replaceStr).append("@").append(email[1]).toString();
            }else{
                return sb.append(email[0].substring(0,3)).append(replaceStr).append("@").append(email[1]).toString();
            }
        }
        return source;
    }

    public static String hiddenEmail(String source,int preLen, int sufLen,String replaceStr){
        if(StringUtils.isBlank(source))
            return "";
        StringBuilder sb = new StringBuilder();
        if(source.indexOf("@") > 0){    //如果是邮箱只截邮箱名
            String email = source.split("@")[0];
            if(email.length()<=(preLen+sufLen)){
                do{
                    preLen --;
                    sufLen --;
                }while (email.length()<=(preLen+sufLen));
                preLen = preLen>0?preLen:1;
                sufLen = sufLen>0?sufLen:1;
            }
            return sb.append(hiddenString(email, preLen, sufLen,replaceStr)).append("@").append(source.split("@")[1]).toString();
        }
        return source;
    }

    public static String hiddenName(String name){
        String result;
        if(name==null || name.length()==0) {
            result = "";
        }else if(name.length()==1){
            result = name;
        }else if(name.length()==2){ //姓名为2位数，隐藏姓显示名，如：*磊；
            result = SubStringUtil.hiddenStringBefore(name, 1,"*");
        }else if(name.length()>=3 && name.length()<=7){ //姓名为3~7位数，隐藏前2，其余显示。如：**强，**强强，**强强强强强
            result = SubStringUtil.hiddenStringBefore(name, 2,"**");
        }else{ //姓名为7位以上，显示后5位，其余显示2个*。如：**强强强强强
            result = SubStringUtil.hiddenStringBefore(name, name.length()-5,"**");
        }
        return result;
    }

    /**
     * 字符串解码
     * @param value
     * @param encodingFormat
     * @return
     */
    public static String getDecodingString (String value, String encodingFormat) {
        if (StringUtils.isEmpty(value) || StringUtils.isEmpty(encodingFormat)) {
            return value;
        }
        try {
            value = URLDecoder.decode(value,encodingFormat);
        }catch (Exception e) {
//            logger.info("e{}",e);
            return value;
        }
        return value;
    }

    public static void main(String[] args){
        /** String number = "37************14444423320785";
        String anumber = SubStringUtil.hiddenString(number, 1, 1,"**********");
        System.out.println(anumber);
        System.out.println(anumber.length());
        number = "431022198701188292";
        anumber = SubStringUtil.hiddenString(number, 1, 1,"**********");
        System.out.println(anumber);
        System.out.println(anumber.length());

        String number = "12314";
        String anumber = SubStringUtil.hiddenString(number, 2, 2,"**********");
        System.out.println(anumber);**/
        String email = "lidongxing@jd.com";
        System.out.println(email+" ==> "+SubStringUtil.hiddenEmail(email,2,2,"*****"));
        email = "lido@jd.com";
        System.out.println(email+" ==> "+SubStringUtil.hiddenEmail(email,2,2,"*****"));
        email = "lid@jd.com";
        System.out.println(email+" ==> "+SubStringUtil.hiddenEmail(email,2,2,"*****"));
        email = "ld@jd.com";
        System.out.println(email+" ==> "+SubStringUtil.hiddenEmail(email,2,2,"*****"));
        email = "l@jd.com";
        System.out.println(email+" ==> "+SubStringUtil.hiddenEmail(email,2,2,"*****"));
        System.out.println("li@jd.com".replaceAll("(\\w?)(\\w+)(\\w)(@\\w+\\.[a-z]+(\\.[a-z]+)?)", "$1******$3$4"));
        String phone = "13146247666";
        System.out.println(phone + "==> " + SubStringUtil.hiddenString(phone, 3, 4, "****"));
    }

}
