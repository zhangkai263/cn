package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.partner.client.PartnerClient;
import com.jdcloud.sdk.service.partner.model.*;
import org.junit.Test;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/11/6 11:03
 * @Email:huangtiande@jd.com
 */
public class PartnerClientTest {

    private static PartnerClient partnerClient;

    static {

        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();

        partnerClient = PartnerClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        partnerClient.setCustomHeader("x-jdcloud-pin", "业务研发Jdcloud_02");
    }

    @Test
    public void queryMyCustomerList(){
        QueryMyCustomerListRequest request = new QueryMyCustomerListRequest();
        request.setRegionId("cn-north-1");
        QueryMyCustomerListResponse response = partnerClient.queryMyCustomerList(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void getSubDistributorListTest(){
        GetSubDistributorListRequest request = new GetSubDistributorListRequest();
        request.setRegionId("cn-north-1");
        GetSubDistributorListResponse response = partnerClient.getSubDistributorList(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void querySubCustomerListTest(){
        QuerySubCustomerListRequest request = new QuerySubCustomerListRequest();
        request.setRegionId("cn.north-1");
        request.setDistributorName("test0120-2ddqq");
        QuerySubCustomerListResponse response = partnerClient.querySubCustomerList(request);
        System.out.println(new Gson().toJson(response));
    }
}
