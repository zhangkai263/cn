package com.huangtiande.test.openapi;

import com.google.gson.Gson;
import com.jdcloud.sdk.auth.CredentialsProvider;
import com.jdcloud.sdk.auth.StaticCredentialsProvider;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.billing.client.BillingClient;
import com.jdcloud.sdk.service.billing.model.ArrearStaticsInfoRequest;
import com.jdcloud.sdk.service.billing.model.ArrearStaticsInfoResponse;
import com.jdcloud.sdk.service.discount.client.DiscountClient;
import com.jdcloud.sdk.service.discount.model.*;
import com.jdcloud.sdk.service.iam.client.IamClient;
import com.jdcloud.sdk.service.partner.client.PartnerClient;
import com.jdcloud.sdk.service.partner.model.QueryMyCustomerListRequest;
import com.jdcloud.sdk.service.partner.model.QueryMyCustomerListResponse;
import com.jdcloud.sdk.service.resourcecenter.client.ResourcecenterClient;
import com.jdcloud.sdk.service.resourcecenter.model.*;
import com.jdcloud.sdk.service.user.client.UserClient;
import com.jdcloud.sdk.service.user.model.*;
import org.junit.Test;



/**
 * @author huangyichun
 * @date 2018/10/8
 * <p>
 * 调用分为：系统调用和外部调用
 * 系统调用：1.控制台调用，传控制台的ak/sk 还需要传header信息 2.服务调用：服务ak/sk
 * 外部调用：传用户的ak/sk即可
 */
public class OpenAPITest {

    //1. 设置accessKey和secretKey
    /*********************************开发环境*****************************************/
//    private static final String endpoint = "192.168.182.82:8000";
//    private static final String accessKeyId = "636B856DCF14D467D313CCB0C0E2B21C";
//    private static final String secretAccessKey = "6EA0C4C1FC1AD060568A1C117E5C0287";

    /*********************************测试环境 控制台系统ak/sk**************************************/
//    private static final String endpoint = "10.226.145.66:8000";
//    private static final String endpoint = "10.226.148.226:8000";
//    private static final String endpoint = "10.226.144.222:8000";
//    private static final String accessKeyId = "DD1B0BFA7BAA5DAED057ACF4817AF55B";
//    private static final String secretAccessKey = "6FC47989E4F4B1F489004F12FFFD89DE";

    /*********************************测试环境 主账号**************************************/
//    private static final String endpoint = "10.226.145.66:8000";
////    private static final String endpoint = "10.226.148.226:8000";
//    private static final String accessKeyId = "A4EAB793BECEAC87A1E3C4FA09B51D84";
//    private static final String secretAccessKey = "5824634574DF82FCFE330B9CBCC5F302";

    /**********************************测试环境 子账号************************************/
//    private static final String endpoint = "10.226.148.63:8000";
//    private static final String accessKeyId = "FEF1F547DF253AE69C8B8C768C6D2D60";
//    private static final String secretAccessKey = "1E11FB3267A1CE20B829C79C055B94FC";


    /**********************************华东预发二期用户ak/sk**************************/
//    private static final String accessKeyId = "2A35DC46E1BF6977EA548909BB27B2A4";// for test
//    private static final String secretAccessKey = "94AD12FFA01AACB7D358550713DEA4A8";
//    private static final String endpoint = "10.226.200.67:8000";
//    private static final String accessKeyId = "E364C1C6B0B2DADE6C7A8B876FC0B0BD";// for test
//    private static final String secretAccessKey = "BB824882BC74094B3580750D6468C4DB";
////    private static final String endpoint = "10.226.200.67:8000";
//    private static final String endpoint = "apigw-stag.openapi.jdcloud.com";


    /**************************预发二期服务ak/sk******************************************/
//    private static final String accessKeyId = "2A35DC46E1BF6977EA548909BB27B2A4";// for test
//    private static final String secretAccessKey = "94AD12FFA01AACB7D358550713DEA4A8 ";
//    private static final String endpoint = "10.226.200.67:8000";

    /**********************************华东预发二期子账号*******************************/
//    private static final String accessKeyId = "DCF12A92F7A565C477B95C94F25BD0BA";// for test
//    private static final String secretAccessKey = "73CC7822ADA41D6292391B71815EFBD4";
//    private static final String endpoint = "10.226.200.67:8000";//host :10.226.202.225 apigw-stag.openapi.jdcloud.com

    /*******************************预发二期控制台ak/sk**************************************/
//    private static final String accessKeyId = "DD1B0BFA7BAA5DAED057ACF4817AF55B";
//    private static final String secretAccessKey = "6FC47989E4F4B1F489004F12FFFD89DE";
//    private static final String endpoint = "10.226.200.67:8000";
//    private static final String endpoint = "10.226.200.67:8000";
//    private static final String accessKeyId = "016EE6947CDDB725F2E692DD4AF76A07";
//    private static final String secretAccessKey = "367BE998A060849C7F748B49636CE5AD";
//    private static final String endpoint = "apigw-stag.openapi.jdcloud.com";

      /*********************************线上环境ak/sk******************************************/
    private static final String accessKeyId = "97327768124B1D8AD2B9272483446095";
    private static final String secretAccessKey = "86B060FC237C9FB7289121B6AFE32DE1";
    private static final String endpoint = "apigw-internal.cn-north-1.jcloudcs.com";

    private static CredentialsProvider credentialsProvider = new StaticCredentialsProvider(accessKeyId, secretAccessKey);

    private static UserClient userClient;

    private static ResourcecenterClient resourcecenterClient;

    private static IamClient iamClient;

    private static DiscountClient discountClient;

    private static PartnerClient partnerClient;

    private static BillingClient billingClient;


    static {
        Environment ev = new Environment.Builder()
                .endpoint(endpoint)
                .build();


        userClient = UserClient.builder()
                .credentialsProvider(credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build()) //使用HTTP
                .environment(ev)
                .build();
        userClient.setCustomHeader("x-jdcloud-pin", "huangyichun0018");

        resourcecenterClient = ResourcecenterClient.builder()
                .credentialsProvider(credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        resourcecenterClient.setCustomHeader("x-jdcloud-pin", "huangyichun0018");


        iamClient = IamClient.builder()
                .credentialsProvider(credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build()) //使用HTTP
                .environment(ev)
                .build();
        userClient.setCustomHeader("x-jdcloud-pin", "huangyichun0018");


        discountClient = DiscountClient.builder()
                .credentialsProvider(credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        discountClient.setCustomHeader("x-jdcloud-pin", "jcloud_sfRczzI");

        partnerClient = PartnerClient.builder()
                .credentialsProvider(credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        partnerClient.setCustomHeader("x-jdcloud-pin", "福建知鱼科技有限公司");

        billingClient = BillingClient.builder()
                .credentialsProvider(credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        billingClient.setCustomHeader("x-jdcloud-pin", "CapAutomation");


    }

    //测试账号报备的openapi
    @Test
    public void userReportOpenApiTest(){
       /* DescribeUserReportRequest request = new DescribeUserReportRequest();
        request.setPin("wwjtest");
        request.setRegionId("huabei");
        DescribeUserReportResponse response = userClient.describeUserReport(request);
        System.out.println(new Gson().toJson(response));*/
    }


    @Test
    public void getPinsTest(){
        DescribePinsRequest request = new DescribePinsRequest();
        request.setAffiliation("外部");
        request.setCurrentPage(1);
        request.setPageSize(2);
        request.setRegionId("cn-north-1");
        DescribePinsResponse response = userClient.describePins(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getUserReportPropertyTest(){
        DescribeUserReportPropertyRequest reportPropertyRequest = new DescribeUserReportPropertyRequest();
        reportPropertyRequest.setPin("jcloud_nzYAEgT");
//        reportPropertyRequest.setPin("huangyichun0018");
//        reportPropertyRequest.setPin("zhangsan");
        reportPropertyRequest.setRegionId("cn-north-1");
        DescribeUserReportPropertyResponse reportResponse = userClient.describeUserReportProperty(reportPropertyRequest);
        System.out.println(new Gson().toJson(reportResponse));
    }

    @Test
    public void getUserSellerTest(){
        DescribeUserSellerRequest request = new DescribeUserSellerRequest();
        request.setPin("ecop-186");
//        request.setPin("");
        request.setRegionId("cn-north-1");
        DescribeUserSellerResponse response = userClient.describeUserSeller(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void describeNameAndCodeTest(){
        DescribeNameAndCodeRequest request = new DescribeNameAndCodeRequest();
        request.setRegionId("cn-north-1");
//        request.setName("测试产品线");
        DescribeNameAndCodeResponse response = resourcecenterClient.describeNameAndCode(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getConfigPropertyTest(){
        GetConfigPropertyRequest request = new GetConfigPropertyRequest();
        request.setRegionId("cn-north-1");
        request.setServiceId(416);
        GetConfigPropertyResponse response = resourcecenterClient.getConfigProperty(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getNameAndCodeTest(){
        GetNameAndCodeRequest request = new GetNameAndCodeRequest();
        request.setRegionId("cn.north-1");
        GetNameAndCodeResponse response = resourcecenterClient.getNameAndCode(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeServiceLineTest(){
        DescribeServiceLineRequest request = new DescribeServiceLineRequest();
        request.setRegionId("cn-north-1");
        request.setServiceCode("contentsecurity");
        DescribeServiceLineResponse response = resourcecenterClient.describeServiceLine(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getServiceLinePropertyTest() {
        GetServiceLinePropertyRequest request = new GetServiceLinePropertyRequest();
        request.setRegionId("cn-north-1");
        request.setServiceId(299);
        GetServiceLinePropertyResponse response = resourcecenterClient.getServiceLineProperty(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void getRegionAndAzDetailTest(){
        GetRegionAndAzDetailRequest request = new GetRegionAndAzDetailRequest();
        request.setRegionId("cn-north-1");
        request.setId(12);
        GetRegionAndAzDetailResponse response = resourcecenterClient.getRegionAndAzDetail(request);
        System.out.println(new Gson().toJson(response));
    }


    @Test
    public void userTest(){
        DescribeUsersRequest request = new DescribeUsersRequest();
        request.setRegionId("region");
        UserReqVo reqVo = new UserReqVo();
//        reqVo.setName("京东5");
        reqVo.setPin("huangyichun0018");
        request.setUserReqVo(reqVo);
        DescribeUsersResponse response = userClient.describeUsers(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void controlManageTest(){
        DescribeControlManagementSummaryRequest request = new DescribeControlManagementSummaryRequest();
        DescribeControlManagementSummaryResponse response = userClient.describeControlManagementSummary(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void asyncSendEmailSmsTest(){
       /* AsyncSendEmailSmsRequest request = new AsyncSendEmailSmsRequest();
        EmailSmsInfo emailSmsInfo = new EmailSmsInfo();
        emailSmsInfo.setCreatePin("zhangsan");
        emailSmsInfo.setTitle("测试邮箱");
        emailSmsInfo.setSendType(1);//1-发邮箱,2-发短信
        emailSmsInfo.setContent("测试邮件正文");
        List<String> emails = new ArrayList<String>();
        emails.add("huangtiande@jd.com");
        emailSmsInfo.setTemplateId(1);
        emailSmsInfo.setTemplateParam();
        emailSmsInfo.setReceives(emails);
        emailSmsInfo.setSmsMessageSource("default");
        request.emailSmsInfoReqVo();*/
    }

    /**
     * 查看折扣率和有效时间
     */
    @Test
    public void describeDiscountAndValidTimeTest(){
        discountClient.setCustomHeader("x-jdcloud-pin", "jcloud_sfRczzI");
        DescribeDiscountAndValidTimeRequest request = new DescribeDiscountAndValidTimeRequest();
        request.setRegionId("cn-north-1");
        DescribeDiscountAndValidTimeResponse response = discountClient.describeDiscountAndValidTime(request);
        System.out.println(new Gson().toJson(response));
    }


    /**
     * 查看当前pin是否可以设置折扣
     */
  /*   @Test
   public void describeAuthPinsTest(){
         discountClient.setCustomHeader("x-jdcloud-pin","huangyichun0018");
         DescribeAuthPinRequest request = new DescribeAuthPinRequest();
        request.setRegionId("cn-north-1");
        DescribeAuthPinResponse response = discountClient.describeAuthPin(request);
        System.out.println(new Gson().toJson(response));
    }*/

    /**
     * 创建折扣
     */
    @Test
    public void createDiscountTest(){
        CreateDiscountInfo info = new CreateDiscountInfo();
        info.setDiscount(90);
        info.setReceiverPin("huangyichun0018");
        CreateDiscountRequest request = new CreateDiscountRequest();
        request.setCreateDiscountInfo(info);
        request.setRegionId("cn-north-1");
        CreateDiscountResponse response = discountClient.createDiscount(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查看折扣信息和设置记录
     */
    @Test
    public void describeDiscountsTest(){
        DescribeDiscountsRequest request = new DescribeDiscountsRequest();
        DescribeDiscountInfo info = new DescribeDiscountInfo();
        info.setDescribeType(1);
        info.setPageSize(20);
        info.setCurrentPage(1);
        request.setRegionId("cn-north-1");
        request.setDescribeDiscountInfo(info);
        DescribeDiscountsResponse response = discountClient.describeDiscounts(request);
        System.out.println(new Gson().toJson(response));

    }

    /**
     * 查看用户pin是否已经存在折扣
     */
    @Test
    public void describeExistedDiscount(){
        DescribeExistedDiscountRequest request = new DescribeExistedDiscountRequest();
        request.setPin("huangyichun0018");
        request.setRegionId("cn-north-1");
        DescribeExistedDiscountResponse response = discountClient.describeExistedDiscount(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 禁用折扣
     */
    @Test
    public void disabledDiscountPermissionTest(){
        DisabledDiscountPermissionRequest request = new DisabledDiscountPermissionRequest();
        DisabledDiscountPermissionInfo info = new DisabledDiscountPermissionInfo();
        info.setId(6135L);
        info.setForbiddenReason("禁用openapi测试");
        request.setDisabledDiscountPermissionInfo(info);
        request.setRegionId("cn-north-1");
        DisabledDiscountPermissionResponse response = discountClient.disabledDiscountPermission(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查询我的客户
     */
    @Test
    public void describeCustomers(){
        discountClient.setCustomHeader("x-jdcloud-pin", "Jdcloud_02");
        DescribeMyCustomersRequest  request = new DescribeMyCustomersRequest();
        request.setPageIndex(1);
        request.setPageSize(10);
        request.setRegionId("cn-north-1");
        DescribeMyCustomersResponse response = discountClient.describeMyCustomers(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查询我的渠道商
     */
    @Test
    public void describeSubDistributorsTest() {
        discountClient.setCustomHeader("x-jdcloud-pin", "820084725_189091883");
        DescribeSubDistributorsRequest request = new DescribeSubDistributorsRequest();
        request.setRegionId("cn-north-1");
        request.setPageSize(10);
        request.setPageIndex(1);
        DescribeSubDistributorsResponse response = discountClient.describeSubDistributors(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查询渠道商的客户
     */
    @Test
    public void describeSubCustomersTest(){
        DescribeSubCustomersRequest request = new DescribeSubCustomersRequest();
        discountClient.setCustomHeader("x-jdcloud-pin", "820084725_189091883");
        request.setDistributorName("2级服务商");
        request.setRegionId("cn-north-1");
        request.setPageIndex(1);
        request.setPageSize(10);
        DescribeSubCustomersResponse response = discountClient.describeSubCustomers(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeCustomerOrDistributorTest(){
        discountClient.setCustomHeader("x-jdcloud-pin", "xuejiandangchang");
        DescribeCustomerOrDistributorRequest request = new DescribeCustomerOrDistributorRequest();
        request.setRegionId("cn-north-1");
        request.setTypeIndex(3);
//        request.setDistributorPin();
        request.setPin("业务研发Jdcloud_01");
        DescribeCustomerOrDistributorResponse response = discountClient.describeCustomerOrDistributor(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void queryMyCustomerList(){
        QueryMyCustomerListRequest request = new QueryMyCustomerListRequest();
        request.setRegionId("cn-north-1");
        QueryMyCustomerListResponse response = partnerClient.queryMyCustomerList(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void arrearStaticsInfoTest(){
        ArrearStaticsInfoRequest request = new ArrearStaticsInfoRequest();
        request.setRegionId("cn-north-1");
        ArrearStaticsInfoResponse response = billingClient.arrearStaticsInfo(request);
        System.out.println(new Gson().toJson(response));
    }









  /*  @Test
    public void asyncSendEmailSms() {
        AsyncSendEmailSmsRequest request = new AsyncSendEmailSmsRequest();
        EmailSmsInfo emailSmsInfo = new EmailSmsInfo();
        emailSmsInfo.setCreatePin("huangyichun");
        emailSmsInfo.setContent("测试asyncSendEmailSms内容");
        emailSmsInfo.setReceives(Arrays.asList("huangyichun@jd.com"));
        emailSmsInfo.setSendType(1);
        emailSmsInfo.setTitle("测试asyncSendEmailSms");
        emailSmsInfo.setSmsMessageSource("WARNING_ORDER");

        emailSmsInfo.setTemplateId(1755);
        emailSmsInfo.setTemplateParam(Collections.singletonList("你好，世界"));
        request.setEmailSmsInfoReqVo(emailSmsInfo);
        AsyncSendEmailSmsResponse response = messageClient.asyncSendEmailSms(request);
        System.out.println(JSON.toJSON(response));
    }

    @Test
    public void sendWithoutLimit() {
        SendWithoutLimitRequest request = new SendWithoutLimitRequest();
        EmailSmsInfo emailSmsInfo = new EmailSmsInfo();
        emailSmsInfo.setCreatePin("huangyichun0018");
        emailSmsInfo.setContent("测试sendWithoutLimit");
        emailSmsInfo.setReceives(Arrays.asList("jcloud_DYLqnKi"));
        emailSmsInfo.setSendType(1);
        emailSmsInfo.setTitle("测试sendWithoutLimit");
        emailSmsInfo.setSmsMessageSource("WARNING_ORDER");

        emailSmsInfo.setTemplateId(1755);
        emailSmsInfo.setTemplateParam(Collections.singletonList("你好，世界"));

        request.setEmailSmsInfoReqVo(emailSmsInfo);

        SendWithoutLimitResponse response = messageClient.sendWithoutLimit(request);
        System.out.println(JSON.toJSON(response));
    }

    @Test
    public void sendOutSiteNotice() {
        SendOutSiteNoticeRequest request = new SendOutSiteNoticeRequest();
        SendOutSiteNotice notice = new SendOutSiteNotice();
        notice.setPin("huangyichun0018");
        notice.setEmailContent("hello world test");
        notice.setEmailSubject("");
        notice.setNotifyBusinessTypeEnum("ZYSF");

        notice.setSmsMessageSource("WARNING_ORDER");

        notice.setTemplateId(1755);
        notice.setTemplateParam(Collections.singletonList("你好，世界"));

        request.setSendOutSiteNoticeReqVo(notice);
        SendOutSiteNoticeResponse response = messageClient.sendOutSiteNotice(request);
        System.out.println(JSON.toJSONString(response));
    }

    @Test
    public void sendBatchAudioNotice() {
        SendBatchAudioNoticeRequest request = new SendBatchAudioNoticeRequest();
        SendBatchAudioNotice sendBatchAudioNotice = new SendBatchAudioNotice();
        sendBatchAudioNotice.setPhoneNumbers(Arrays.asList("17780661974"));
        sendBatchAudioNotice.setPin("huangyichun");
        sendBatchAudioNotice.setSmsMessageSource("VERIFY_UC");
        sendBatchAudioNotice.setTxt("hello word");

        request.setSendBatchAudioReqVo(sendBatchAudioNotice);

        SendBatchAudioNoticeResponse response = messageClient.sendBatchAudioNotice(request);
        System.out.println(new Gson().toJson(response));

    }

*//*    @Test
    public void sendBatchSmsMessage() {
        SendBatchSmsMessageRequest request = new SendBatchSmsMessageRequest();
        SendBatchMsg vo = new SendBatchMsg();
        vo.setMobileNumSet(Collections.singletonList("17780661974"));
        vo.setPin("huangyichun0018");
        vo.setSmsMessageSource("VERIFY_UC");
//        vo.set
    }*//*

    @Test
    public void describePrivilegeNew() {
        DescribePrivilegeNewRequest request = new DescribePrivilegeNewRequest();
        request.setPin("jd_6a8988b7e2b39");
        request.setRegionId("huabei");
        DescribePrivilegeNewResponse response = client.describePrivilegeNew(request);
        System.out.println(new Gson().toJson(response));
    }


    @Test
    public void testOrder() {
        PayOrderRequest request = new PayOrderRequest();
        request.setRegionId("cn-north-1");
        request.setOrderNumber("121936822472095035");
        request.setPin("820084725_189091883");
        request.setPaymentChannel(0);
        request.setBalancePrice(26);
        request.setMoneyPrice(0);
        request.setVoucherPrice(0);
        PayOrderResponse response = orderClient.payOrder(request);
//        System.out.println("orderPay");
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void createUserAccessKey() {
        CreateUserAccessKeyRequest request = new CreateUserAccessKeyRequest();
        request.setRegionId("cn-east-1");
        CreateUserAccessKeyResponse response = iamClient.createUserAccessKey(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void testDataFactory() {
        DescribeDashboardAuthRequest request = new DescribeDashboardAuthRequest();
        request.setRegionId("cn-east-1");
        DescribeDashboardAuthResponse response = datafactoryClient.describeDashboardAuth(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void authenticate() {
        AuthenticateRequest request = new AuthenticateRequest();
        AuthenticationInfo info = new AuthenticationInfo();

        info.setAction("rds:describeIndexPerformance");
        info.setAccount("业务研发Jdcloud_02");
        info.setSubUser("jcloud_NQARFSx");
        info.setResource("jrn:rds:*:642308837706:bggrzmc4x61k");
//        info.setAction("baseanti:setCleanThreshold");
//        info.setResource("jrn:baseanti:cn-north-1:399841413866:ipResources/fip-sutqasducf");
        request.setAuthenticationInfo(info);
        AuthenticateResponse response = iamClient.authenticate(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void querySubUserAllPolicies() {
        DescribeSubUserPossessionPoliciesRequest request = new DescribeSubUserPossessionPoliciesRequest();
        request.setSubUser("ssl_reader");
        DescribeSubUserPossessionPoliciesResponse response = iamClient.describeSubUserPossessionPolicies(request);
        System.out.println(new Gson().toJson(response));
    }



    @Test
    public void createLoginProfile() {
        CreateLoginProfileRequest request = new CreateLoginProfileRequest();
        request.setSubUser("huangyichun");
        CreateLoginProfileInfo info = new CreateLoginProfileInfo();
        info.autoGeneratePassword(true);
        info.mFABindRequired(true);
        info.passwordResetRequired(true);
        request.setCreateLoginProfileInfo(info);
        CreateLoginProfileResponse response = iamClient.createLoginProfile(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeBaseInfo() {
        DescribeBaseInfoRequest request = new DescribeBaseInfoRequest();
        request.setRegionId("cn-north-1");
        request.setPin("huangyichun0018");
        DescribeBaseInfoResponse response = iamClient.describeBaseInfo(request);
        System.out.println(response.getResult().getAccountBalance());
        System.out.println(response.getResult().getCscEmail());
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void updateLoginProfile() {
        UpdateLoginProfileRequest request = new UpdateLoginProfileRequest();
        request.setSubUser("huangyichun");
        UpdateLoginProfileInfo info = new UpdateLoginProfileInfo();
        info.setMFABindRequired(false);
        info.setPasswordResetRequired(false);
        info.setAutoGeneratePassword(false);
        request.setUpdateLoginProfileInfo(info);
        UpdateLoginProfileResponse response = iamClient.updateLoginProfile(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void queryLoginProfile() {
        DescribeLoginProfileRequest request = new DescribeLoginProfileRequest();
        request.setSubUser("huangyichun");
        DescribeLoginProfileResponse response = iamClient.describeLoginProfile(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void deleteLoginProfile() {
        DeleteLoginProfileRequest request = new DeleteLoginProfileRequest();
        request.setSubUser("huangyichun");
        DeleteLoginProfileResponse response = iamClient.deleteLoginProfile(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeUserAccessKeys() {
        DescribeUserAccessKeysRequest request = new DescribeUserAccessKeysRequest();
        request.setRegionId("north-cn-1");
        DescribeUserAccessKeysResponse response = iamClient.describeUserAccessKeys(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeUserInfo() {
        DescribeUserInfoRequest request = new DescribeUserInfoRequest();
        request.setAccessKey("DCF12A92F7A565C477B95C94F25BD0BA");
//        request.setAccountId("417430605778");
        request.setRegionId("north-cn-1");
        DescribeUserInfoResponse response = iamClient.describeUserInfo(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void createVirtualMFADevice() {
        CreateVirtualMFADeviceRequest request = new CreateVirtualMFADeviceRequest();
        request.setBoundAccount("huangyichun121");
        CreateVirtualMFADeviceResponse response = iamClient.createVirtualMFADevice(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describePasswordPolicy() {
        DescribePasswordPolicyRequest request = new DescribePasswordPolicyRequest();
        DescribePasswordPolicyResponse response = iamClient.describePasswordPolicy(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void attachRolePolicy() {
        AttachRolePolicyRequest request = new AttachRolePolicyRequest();
        request.setPolicyName("Marry_role_Policy23");
        request.setRoleName("Marry_role");
        AttachRolePolicyResponse response = iamClient.attachRolePolicy(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void describeRolePolicies() {
        DescribeRolePoliciesRequest request = new DescribeRolePoliciesRequest();
        request.setRoleName("Marry_role");
        request.setPageNumber(1);
        request.setPageSize(10);
        request.sort(1);
        DescribeRolePoliciesResponse response = iamClient.describeRolePolicies(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void updatePasswordPolicy() {
        UpdatePasswordPolicyRequest request = new UpdatePasswordPolicyRequest();

        PasswordPolicy info = new PasswordPolicy();
        info.setAge(10);
        info.setExpirationOperation(1);
        info.setRetryTimes(5);
        info.setReusePrevention(3);
        info.setValidLoginDuration(100);

        PasswordPolicyRule rule = new PasswordPolicyRule();
        rule.setRequireLowercaseCharacters(true);
        rule.setRequireNumbers(true);
        info.setRule(rule);
        info.setLength(15);

        request.setUpdatePasswordPolicyInfo(info);

        UpdatePasswordPolicyResponse response = iamClient.updatePasswordPolicy(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void deletePasswordPolicy() {
        DeletePasswordPolicyRequest request = new DeletePasswordPolicyRequest();
        DeletePasswordPolicyResponse response = iamClient.deletePasswordPolicy(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void assumeServiceRole() {
        AssumeServiceRoleRequest request = new AssumeServiceRoleRequest();

    }

    @Test
    public void createSubUser() {

        CreateSubUserRequest request = new CreateSubUserRequest();
        CreateSubUserInfo info = new CreateSubUserInfo();
        String email = "1728712@qq_.com";
        info.setCreateAk(true);
        info.setConsoleLogin(true);
        info.setDescription(" ");
        info.setEmail(email);
        info.autoGeneratePassword(true);
        info.setPhone("17780661974");
        info.needResetPassword(true);
        info.setName("ju2323");
        info.setAutoGeneratePassword(true);
        request.setCreateSubUserInfo(info);
        CreateSubUserResponse response = iamClient.createSubUser(request);

//        Assert.assertEquals(response.getResult().getSubUser().getEmail(), email);
        System.out.println(new Gson().toJson(response));
    }


*//*    @Test
    public void openMFASetting() {
        OpenMFASettingRequest request = new OpenMFASettingRequest();
        request.setSubUser("huangyichun");
        OpenMFASettingResponse response = iamClient.openMFASetting(request);
        System.out.println(new Gson().toJson(response));
    }*//*

    @Test
    public void describeMFASetting() {
        DescribeVirtualMFARequest request = new DescribeVirtualMFARequest();
        request.setQueriedAccount("huang@.com");
        DescribeVirtualMFAResponse response = iamClient.describeVirtualMFA(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void deleteSubUser() {
        DeleteSubUserRequest request = new DeleteSubUserRequest();
        request.setSubUser("ttcomweswewds");
        DeleteSubUserResponse response = iamClient.deleteSubUser(request);
        System.out.println(new Gson().toJson(response));
    }


    @Test
    public void test() {
        System.out.println("ｆｊｗｆｗｅｑｗ".length());
        System.out.println(this.getClass().getName());
    }

    @Test
    public void describeSubUser() {
        DescribeSubUserRequest request = new DescribeSubUserRequest();
//        request.setSubUser("tt@--_.com");
        request.setSubUser("jcloud_NQARFSx");
        DescribeSubUserResponse response = iamClient.describeSubUser(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeSubUserPin() {
        DescribeSubUserPinRequest request = new DescribeSubUserPinRequest();
        request.setSubUser("username");
        DescribeSubUserPinResponse response = iamClient.describeSubUserPin(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void createSubUserAccesskey() {
        CreateSubUserAccessKeyRequest request = new CreateSubUserAccessKeyRequest();
        request.setSubUser("huangyichun");
        CreateSubUserAccessKeyResponse response = iamClient.createSubUserAccessKey(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeSubUserAccessKey() {
        DescribeSubUserAccessKeysRequest request = new DescribeSubUserAccessKeysRequest();
        request.setSubUser("huangyichun");
        DescribeSubUserAccessKeysResponse response = iamClient.describeSubUserAccessKeys(request);
        System.out.println(new Gson().toJson(response));
    }

   *//* @Test
    public void enableSubUserAccessKey(){
        EnableSubUserAccessKeyRequest
    }*//*

    @Test
    public void updateSubUser() {
        UpdateSubUserRequest request = new UpdateSubUserRequest();

        UpdateSubUserInfo info = new UpdateSubUserInfo();
        info.setDescription("1234567890QWERTYUIOPasdfghjklz1234567890QWERTYUIOPasdfghjklz1234567890QWERTYUIOPasdfghjklz1234567890QWERTYUIOPasdfghjklz1234567890QWERTYUIOPasdfghjklz1234567890QWERTYUIOPasdfghjklz1234567890QWERTYUIOPasdfghjklz1234567890QWERTYUIOPasdfghjklz1234567890你好啊大熊猫7");
        info.setEmail("782367@jd.com");
        info.setPhone("0086-17780661782");
        request.setUpdateSubUserInfo(info);

        request.setSubUser("Marry_test1");

        UpdateSubUserResponse response = iamClient.updateSubUser(request);
        System.out.println(new Gson().toJson(response));
    }

    *//**
     * 清空子用户
     *//*
    @Test
    public void deleteSubUsers() {
        DescribeSubUsersRequest request = new DescribeSubUsersRequest();
        DescribeSubUsersResponse response = iamClient.describeSubUsers(request);
        for (int i = 0; i < response.getResult().getTotal() / 20 + 1; i++) {
            DescribeSubUsersRequest request1 = new DescribeSubUsersRequest();
            //4. 执行请求
            DescribeSubUsersResponse response1 = iamClient.describeSubUsers(request1);
            request.setPageNumber(1);
            request.setPageSize(20);
            //5. 处理响应
            List<SubUser> subUserList1 = response1.getResult().getSubUsers();
            subUserList1.forEach(
                    s -> {
                        DeleteSubUserRequest request2 = new DeleteSubUserRequest();
                        request2.setSubUser(s.getName());
                        DeleteSubUserResponse response2 = iamClient.deleteSubUser(request2);
                        System.out.println(new Gson().toJson(response2));
                    }
            );
        }
    }

    @Test
    public void describeSubUsers() {
        //3. 设置请求参数
        DescribeSubUsersRequest request = new DescribeSubUsersRequest();
//        request.setPageSize(1000);
//        request.setPageNumber(1);
//        request.setSort(1);
//        request.setKeyword(" ");
        //4. 执行请求
        DescribeSubUsersResponse response = iamClient.describeSubUsers(request);
        //5. 处理响应
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeSubUserGroups() {
        DescribeSubUserGroupsRequest request = new DescribeSubUserGroupsRequest();
        request.setSubUser("JaneCloud002");
        DescribeSubUserGroupsResponse response = iamClient.describeSubUserGroups(request);
        System.out.println(new Gson().toJson(response));
    }

    *//**
     * 删除用户群组
     *//*
    @Test
    public void deleteGroups() {
        DescribeGroupsRequest firstRequest = new DescribeGroupsRequest();
        int sum = iamClient.describeGroups(firstRequest).getResult().getTotal();
        for (int i=0; i < sum / 20 + 1; i++) {
            DescribeGroupsRequest request = new DescribeGroupsRequest();
            request.setPageSize(20);
            request.setPageNumber(1);
            iamClient.describeGroups(request).getResult().getGroups().stream().map(Group::getName).forEach(
                    name -> {
                        DeleteGroupRequest request1 = new DeleteGroupRequest();
                        request1.setGroupName(name);
                        DeleteGroupResponse response = iamClient.deleteGroup(request1);
                        System.out.println(new Gson().toJson(response));
                    }
            );
        }
    }

    @Test
    public void addSubUserToGroup() {
        AddSubUserToGroupRequest request = new AddSubUserToGroupRequest();
        request.setSubUser("huangyichun1091");
        request.setGroupName("createName");
        AddSubUserToGroupResponse response = iamClient.addSubUserToGroup(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void removeSubUserFromGroup() {
        RemoveSubUserFromGroupRequest request = new RemoveSubUserFromGroupRequest();
        request.setSubUser("JaneCloud002");
        request.setGroupName("createName");
        RemoveSubUserFromGroupResponse response = iamClient.removeSubUserFromGroup(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeControlManagementSummary() {
        DescribeControlManagementSummaryRequest request = new DescribeControlManagementSummaryRequest();
        DescribeControlManagementSummaryResponse response = client.describeControlManagementSummary(request);
//        System.out.println(response.getResult().getControlManagementSummary().getGroupCount());
        System.out.println(new Gson().toJson(response));
    }


    @Test
    public void describeSubUserPolicies() {
        DescribeAttachedSubUserPoliciesRequest request = new DescribeAttachedSubUserPoliciesRequest();
        request.setSubUser("jd_cdntest_sub");
        DescribeAttachedSubUserPoliciesResponse response = iamClient.describeAttachedSubUserPolicies(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void attachSubUserPolicy() {
        AttachSubUserPolicyRequest request = new AttachSubUserPolicyRequest();
        request.setSubUser("huangyichun");
        request.setPolicyName("JDCloudServerAdmin");
        AttachSubUserPolicyResponse response = iamClient.attachSubUserPolicy(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void detachSubUserPolicy() {
        DetachSubUserPolicyRequest request = new DetachSubUserPolicyRequest();
        request.setSubUser("JaneCloud002");
        request.setPolicyName("JDCloudKeypairRead");
        DetachSubUserPolicyResponse response = iamClient.detachSubUserPolicy(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describePolicies() {
        DescribePoliciesRequest request = new DescribePoliciesRequest();
//        request.setPageNumber(1);
        request.setPageSize(20);
        request.setSort(1);
        DescribePoliciesResponse response = iamClient.describePolicies(request);
        System.out.println(new Gson().toJson(response));
    }


    *//**
     * 清空策略
     *//*
    @Test
    public void deletePolicies() {
        DescribePoliciesRequest firstRequest = new DescribePoliciesRequest();
        int number = iamClient.describePolicies(firstRequest).getResult().getTotal();
        for (int i = 0; i < number / 20 + 1; i++) {
            DescribePoliciesRequest request = new DescribePoliciesRequest();
            request.setPageNumber(1);
            request.setPageSize(20);
            DescribePoliciesResponse response = iamClient.describePolicies(request);
            response.getResult().getPolicies().forEach(
                    policy -> {
                        DeletePolicyRequest request1 = new DeletePolicyRequest();
                        request1.setPolicyName(policy.getName());
                        DeletePolicyResponse response1 = iamClient.deletePolicy(request1);
                        System.out.println(new Gson().toJson(response1));
                    }
            );
        }
    }



 *//*   @Test
    public void describeConsoleLogin() {
        DescribeConsoleLoginRequest request = new DescribeConsoleLoginRequest();
        request.setSubUser("huangyichun");
        DescribeConsoleLoginResponse response = iamClient.describeConsoleLogin(request);
        System.out.println(new Gson().toJson(response));
    }*//*


*//*    @Test
    public void openConsoleLogin() {
        OpenConsoleLoginRequest request = new OpenConsoleLoginRequest();
        OpenConsoleLoginInfo info = new OpenConsoleLoginInfo();
        info.setAutoGeneratePassword(true);
        info.setNeedResetPassword(false);
        info.setNewPassword(null);
        request.setOpenConsoleLoginInfo(info);
        request.setSubUser("huangyichun3");
        OpenConsoleLoginResponse response = iamClient.openConsoleLogin(request);
        System.out.println(new Gson().toJson(response));
    }*//*

    @Test
    public void changePassword() {
        ChangePasswordRequest request = new ChangePasswordRequest();
        request.setNewPassword("wefwhuiwfewefwfe2");
        request.setOldPassword("1qaz@WSX");
        request.setSubUser("weiwei");
        ChangePasswordResponse response = iamClient.changePassword(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void resetPassword() {
        ResetPasswordRequest request = new ResetPasswordRequest();
//        request.setNewPassword("huangyichun12345678");
        request.setAutoGeneratePassword(true);
        request.setSubUser("weiwei");
        ResetPasswordResponse response = iamClient.resetPassword(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void matchPassword() {
//        String reg = "[^\\x00-\\xff]+";
        String reg = "[a-zA-Z0-9_-]+";
        Pattern pattern = Pattern.compile(reg);
        Matcher matcher = pattern.matcher("><");
        System.out.println(matcher.matches());
    }


    @Test
    public void createMatchGroup() {
        IntStream.rangeClosed(1, 100).forEach(i -> createGroup("huang" + i));
    }

    private void createGroup(String name) {
        CreateGroupRequest request = new CreateGroupRequest();
        CreateGroupInfo info = new CreateGroupInfo();
        info.setDescription("134561");
        System.out.println(info.getDescription().length());
        info.setName(name);
        request.setCreateGroupInfo(info);
        CreateGroupResponse response = iamClient.createGroup(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeGroups() {
        DescribeGroupsRequest request = new DescribeGroupsRequest();
//        request.setSort(1);
//        request.setPageNumber(1);
//        request.setPageSize(20);
        request.setKeyword("user1");
        DescribeGroupsResponse response = iamClient.describeGroups(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void createDescribePolicy() {
        CreatePolicyRequest request = new CreatePolicyRequest();
        CreatePolicyInfo info = new CreatePolicyInfo();
        info.setName("fjwifhuwefewfewfffffffffffffffffffffffffffffffffffffffffffffffff");
        System.out.println(info.getName().length());
        info.setDescription("huwef");
        info.setContent("{" +
                "    \"Statement\": [" +
                "        {" +
                "            \"Action\": [" +
                "                \"jcq:createSubscription\"," +
                "                \"jcq:deleteSubscription\"," +
                "                \"jcq:deleteDeadLetters\"," +
                "                \"jcq:cleanMessages\"," +
                "                \"jcq:resetConsumeOffset\"," +
                "                \"jcq:modifySubscriptionAttribute\"," +
                "                \"jcq:resendDeadLetters\"" +
                "            ]," +
                "            \"Effect\": \"Allow\"," +
                "            \"Resource\": [" +
                "                \"*\"" +
                "            ]" +
                "        }" +
                "    ]," +
                "    \"Version\": \"3\"" +
                "}");
        request.setCreatePolicyInfo(info);
        CreatePolicyResponse response = iamClient.createPolicy(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describePolicy() {
        DescribePolicyRequest request = new DescribePolicyRequest();
        request.setPolicyName("JDCloudHipsRead");
        DescribePolicyResponse response = iamClient.describePolicy(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void updateGroup() {
        UpdateGroupRequest request = new UpdateGroupRequest();
        request.setGroupName("group1");
        UpdateGroupInfo info = new UpdateGroupInfo();
        info.setDescription("测试数据");
        request.setUpdateGroupInfo(info);
        UpdateGroupResponse response = iamClient.updateGroup(request);
        System.out.println(new Gson().toJson(response));
    }

 *//*   @Test
    public void describeSensitiveOpSetting() {
        DescribeSOPStatusRequest request = new DescribeSOPStatusRequest();
//        request.setSubUser("huangyichun");
        DescribeSOPStatusResponse response = iamClient.describeSOPStatus(request);
        System.out.println(new Gson().toJson(response));
    }*//*

   *//* @Test
    public void openSensitiveOpSetting() {
        OpenSensitiveOpSettingRequest request = new OpenSensitiveOpSettingRequest();
        request.setSubUser("huangyichun");
        OpenSensitiveOpSettingResponse response = iamClient.openSensitiveOpSetting(request);
        System.out.println(new Gson().toJson(response));
    }*//*

    @Test
    public void createMFA() {
        CreateVirtualMFADeviceRequest request = new CreateVirtualMFADeviceRequest();
        request.setBoundAccount("111111@163co");
        CreateVirtualMFADeviceResponse response = iamClient.createVirtualMFADevice(request);
//        System.out.println(JSONObject.toJSONString(response));
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void bindMFADevice() {
        BindMFADeviceRequest request = new BindMFADeviceRequest();
        request.boundAccount("huangyichun");
        request.setAuthenticationCode1("431405");
        request.setAuthenticationCode2("654084");
        BindMFADeviceResponse response = iamClient.bindMFADevice(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void unbindMFADevice() {
        UnbindMFADeviceRequest request = new UnbindMFADeviceRequest();
//        request.setUnboundAccount("wenyiit");
        UnbindMFADeviceResponse response = iamClient.unbindMFADevice(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeVirtualMFA() {
        DescribeVirtualMFARequest request = new DescribeVirtualMFARequest();
//        request.setQueriedAccount("huangyichun");
        DescribeVirtualMFAResponse response = iamClient.describeVirtualMFA(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeGroupUser() {
        DescribeGroupSubUsersRequest request = new DescribeGroupSubUsersRequest();
        request.setGroupName("huang");
        DescribeGroupSubUsersResponse response = iamClient.describeGroupSubUsers(request);
        System.out.println(new Gson().toJson(response));
    }*/
}
