package com.huangtiande.test.openapi.utils;

import com.google.i18n.phonenumbers.NumberParseException;
import com.google.i18n.phonenumbers.PhoneNumberUtil;
import com.google.i18n.phonenumbers.Phonenumber;
import org.springframework.util.StringUtils;

/**
 * @Description:
 * @author:huangtiande
 * @date:2020/2/26 12:30
 * @Email:huangtiande@jd.com
 */

/**
 * 脱敏规则参考cf: https://cf.jd.com/pages/viewpage.action?pageId=246568925
 */
public class SensitiveInfoHideUtil {

    /**
     * region取值
     * 中国大陆：CN
     * 中国台湾：TW
     * 中国香港：HK
     * 中国澳门：MO
     * @param phone
     * @param region
     * @return
     */
    public static boolean validPhone(String phone,String region) {
        if (StringUtils.isEmpty(phone)) {
            return false;
        }
        try {
            PhoneNumberUtil util = PhoneNumberUtil.getInstance();
            Phonenumber.PhoneNumber phoneNumber = util.parse(phone,region);
            return util.isValidNumber(phoneNumber);

        } catch (NumberParseException e) {
            return false;
        }
    }

    public static String hidePhone(String phone){
        if (validPhone(phone,"CN")) {
            return SubStringUtil.hiddenString(phone,2,4,"*****");
        }else if (validPhone(phone,"HK") || validPhone(phone,"MO")) {
            return SubStringUtil.hiddenString(phone,1,2,"*****");
        }else if (validPhone(phone,"TW")) {
            return SubStringUtil.hiddenString(phone,1,3,"*****");
        }else {
            return phone;
        }
    }

    /**
     * sgd标准技术要求
     * @param email
     * @return
     */
    public static String hideEmail(String email) {
        if(StringUtils.isEmpty(email))
            return "";

        int idx = email.indexOf("@");
        int len = email.substring(0, idx).length();
        if(len < 2) {
            return email.charAt(0) + "***"  + email.substring(idx, email.length());
        } else {
            return email.substring(0, 2).concat("***").concat(email.substring(idx, email.length()));
        }
    }

    public static void main(String[] args) {
        String phone = "15011393998";
        String email = "huangtiande@jd.com";
        String email2 = "h@jd.com";
        System.out.println(phone + "--->"+SensitiveInfoHideUtil.hidePhone(phone));
        System.out.println(email + "--->"+SensitiveInfoHideUtil.hideEmail(email));
        System.out.println(email2 + "--->"+SensitiveInfoHideUtil.hideEmail(email2));
    }



}
