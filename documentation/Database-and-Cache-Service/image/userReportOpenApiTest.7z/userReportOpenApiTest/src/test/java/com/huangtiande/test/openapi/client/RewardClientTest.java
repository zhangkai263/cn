package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.reward.client.RewardClient;
import com.jdcloud.sdk.service.reward.model.*;
import com.jdcloud.sdk.service.user.model.DescribeBindPinsResponse;
import org.junit.Test;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/12/19 11:31
 * @Email:huangtiande@jd.com
 */
public class RewardClientTest {

    private static RewardClient rewardClient;

    static {

        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();

        rewardClient = RewardClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        rewardClient.setCustomHeader("x-jdcloud-pin", "huangtiande0012");
        rewardClient.setCustomHeader("x-jdcloud-erp","huangtiande");
    }

    @Test
    public void describeExchangeRecordsTest(){
        DescribeExchangeRecordsRequest request = new DescribeExchangeRecordsRequest();
        request.setRegionId("cn-north-1");
        request.setCurrentPage(1);
        request.setPageSize(10);
        request.setSite(2);
        request.setStartTime(1575168657000L);
        request.setEndTime(1577935714000L);
        DescribeExchangeRecordsResponse response = rewardClient.describeExchangeRecords(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void modifyExchangeStatusTest(){
        ModifyExchangeStatusRequest request = new ModifyExchangeStatusRequest();
        request.setId(1L);
        request.setRegionId("cn-north-1");
        ModifyExchangeStatusReqVo reqVo = new ModifyExchangeStatusReqVo();
        reqVo.setOperation(1);
        reqVo.setPin("huangtiande0012");
        request.setModifyExchangeStatusReqVo(reqVo);
        ModifyExchangeStatusResponse response = rewardClient.modifyExchangeStatus(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeAccountPointTest(){
        DescribeAccountPointRequest request = new DescribeAccountPointRequest();
        request.setPin("jdcloud_mt");
//        request.setDeviceId("DCD87C04710A");
        request.setSite(2);
        request.setRegionId("cn-north-1");
        DescribeAccountPointResponse response = rewardClient.describeAccountPoint(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void createPointManageApplyTest(){

        CreatePointManageApplyRequest request = new CreatePointManageApplyRequest();
        request.setRegionId("cn-north-1");
        PointManageApplyReqVo reqVo = new PointManageApplyReqVo();
        reqVo.setAssociateNumber("xxxxxx123456");
        reqVo.setOperateType(1);
        reqVo.setSubType(1);
        reqVo.setValue(10L);
        reqVo.setPin("huangtiande0012");
        reqVo.setDeviceId("dd:dd:dd:ff:ee:gg:hh");
        reqVo.setSite(2);
        reqVo.setReason("huangsky test");
        request.setPointManageApplyReqVo(reqVo);
        CreatePointManageApplyResponse response = rewardClient.createPointManageApply(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describePointManageRecordTest(){
        DescribePointManageRecordsRequest request = new DescribePointManageRecordsRequest();
        request.setCurrentPage(1);
        request.setPageSize(20);
        request.setStartTime(1572537600000L);
        request.setEndTime(1577935714000L);
//        request.setPin("huangtiande0012");
        request.setRegionId("cn-north-1");
        request.setSite(2);
        DescribePointManageRecordsResponse response = rewardClient.describePointManageRecords(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeAccountPointsListTest(){
        DescribeAccountPointsListRequest request = new DescribeAccountPointsListRequest();
        request.setCurrentPage(1);
        request.setPageSize(10);
        request.setStartTime(1572537600000L);
        request.setEndTime(1577952421000L);
        request.setRegionId("cn-north-1");
        request.setSite(2);
        DescribeAccountPointsListResponse response = rewardClient.describeAccountPointsList(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void describeAccountPointsDetailsTest(){
        DescribeAccountPointsDetailsRequest request = new DescribeAccountPointsDetailsRequest();
        request.setCurrentPage(1);
        request.setPageSize(10);
        request.setStartTime(1572537600000L);
        request.setEndTime(1577952421000L);
        request.setRegionId("cn-north-1");
        request.setPin("业务研发Jdcloud_03");
//        request.setDeviceId("dd:dd:dd:ff:ee:gg:hh");
        request.setSite(1);
        DescribeAccountPointsDetailsResponse response = rewardClient.describeAccountPointsDetails(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void describeBindDevices(){
        String pin = "jdcloud_mt";
        DescribeBindDevicesRequest request = new DescribeBindDevicesRequest();
        request.setPin(pin);
        request.setRegionId("cn-north-1");
        DescribeBindDevicesResponse response = rewardClient.describeBindDevices(request);
        System.out.println(new Gson().toJson(response));
    }




}
