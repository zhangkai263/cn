package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.discount.client.DiscountClient;
import com.jdcloud.sdk.service.discount.model.*;
import org.junit.Test;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/11/6 11:07
 * @Email:huangtiande@jd.com
 */
public class DiscountClientTest {

    private static DiscountClient discountClient;

    static {

        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();

        discountClient = DiscountClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        discountClient.setCustomHeader("x-jdcloud-pin", "业务研发Jdcloud_02");
    }

    /**
     * 查看折扣率和有效时间
     */
    @Test
    public void describeDiscountAndValidTimeTest(){
//        discountClient.setCustomHeader("x-jdcloud-pin", "jcloud_sfRczzI");
        DescribeDiscountAndValidTimeRequest request = new DescribeDiscountAndValidTimeRequest();
        request.setRegionId("cn-north-1");
        DescribeDiscountAndValidTimeResponse response = discountClient.describeDiscountAndValidTime(request);
        System.out.println(new Gson().toJson(response));
    }


    /**
     * 查看当前pin是否可以设置折扣
     */
  /*   @Test
   public void describeAuthPinsTest(){
         discountClient.setCustomHeader("x-jdcloud-pin","huangyichun0018");
         DescribeAuthPinRequest request = new DescribeAuthPinRequest();
        request.setRegionId("cn-north-1");
        DescribeAuthPinResponse response = discountClient.describeAuthPin(request);
        System.out.println(new Gson().toJson(response));
    }*/

    /**
     * 创建折扣
     */
    @Test
    public void createDiscountTest(){
        CreateDiscountInfo info = new CreateDiscountInfo();
        info.setDiscount(68);
        info.setReceiverPin("jcloud_sfRczzI");
        CreateDiscountRequest request = new CreateDiscountRequest();
        request.setCreateDiscountInfo(info);
        request.setRegionId("cn-north-1");
        CreateDiscountResponse response = discountClient.createDiscount(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查看折扣信息和设置记录
     */
    @Test
    public void describeDiscountsTest(){
        DescribeDiscountsRequest request = new DescribeDiscountsRequest();
        DescribeDiscountInfo info = new DescribeDiscountInfo();
        info.setDescribeType(1);
        info.setPageSize(20);
        info.setCurrentPage(1);
        request.setRegionId("cn-north-1");
        request.setDescribeDiscountInfo(info);
        DescribeDiscountsResponse response = discountClient.describeDiscounts(request);
        System.out.println(new Gson().toJson(response));

    }

    /**
     * 查看用户pin是否已经存在折扣
     */
    @Test
    public void describeExistedDiscount(){
        DescribeExistedDiscountRequest request = new DescribeExistedDiscountRequest();
        request.setPin("jcloudiaas2");
        request.setRegionId("cn-north-1");
        DescribeExistedDiscountResponse response = discountClient.describeExistedDiscount(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 禁用折扣
     */
    @Test
    public void disabledDiscountPermissionTest(){
        DisabledDiscountPermissionRequest request = new DisabledDiscountPermissionRequest();
        DisabledDiscountPermissionInfo info = new DisabledDiscountPermissionInfo();
        info.setId(1380L);
        info.setForbiddenReason("禁用openapi测试");
        request.setDisabledDiscountPermissionInfo(info);
        request.setRegionId("cn-north-1");
        DisabledDiscountPermissionResponse response = discountClient.disabledDiscountPermission(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 根据pin批量禁用
     */
    @Test
    public void disabledPermissionsTest(){
        DisabledPermissionsRequest request = new DisabledPermissionsRequest();
        DisabledPermissionsInfo info = new DisabledPermissionsInfo();
        info.setForbiddenReason("根据pin批量禁用");
        info.setPin("pid-plat");
        request.setDisabledPermissionsInfo(info);
        request.setRegionId("cn-north-1");
        DisabledPermissionsResponse response = discountClient.disabledPermissions(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查询我的客户
     */
    @Test
    public void describeCustomers(){
        discountClient.setCustomHeader("x-jdcloud-pin", "业务研发Jdcloud_02");
        DescribeMyCustomersRequest  request = new DescribeMyCustomersRequest();
        request.setPageIndex(1);
        request.setPageSize(10);
        request.setRegionId("cn-north-1");
        DescribeMyCustomersResponse response = discountClient.describeMyCustomers(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查询我的渠道商
     */
    @Test
    public void describeSubDistributorsTest() {
        discountClient.setCustomHeader("x-jdcloud-pin", "业务研发Jdcloud_02");
        DescribeSubDistributorsRequest request = new DescribeSubDistributorsRequest();
        request.setRegionId("cn-north-1");
        request.setPageSize(10);
        request.setPageIndex(1);
        DescribeSubDistributorsResponse response = discountClient.describeSubDistributors(request);
        System.out.println(new Gson().toJson(response));
    }

    /**
     * 查询渠道商的客户
     */
    @Test
    public void describeSubCustomersTest(){
        DescribeSubCustomersRequest request = new DescribeSubCustomersRequest();
        discountClient.setCustomHeader("x-jdcloud-pin", "820084725_189091883");
        request.setDistributorName("2级服务商");
        request.setRegionId("cn-north-1");
        request.setPageIndex(1);
        request.setPageSize(10);
        DescribeSubCustomersResponse response = discountClient.describeSubCustomers(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeCustomerOrDistributorTest(){
        discountClient.setCustomHeader("x-jdcloud-pin", "xuejiandangchang");
        DescribeCustomerOrDistributorRequest request = new DescribeCustomerOrDistributorRequest();
        request.setRegionId("cn-north-1");
        request.setTypeIndex(3);
//        request.setDistributorPin();
        request.setPin("业务研发Jdcloud_01");
        DescribeCustomerOrDistributorResponse response = discountClient.describeCustomerOrDistributor(request);
        System.out.println(new Gson().toJson(response));
    }

}
