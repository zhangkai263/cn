package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.developer.client.DeveloperClient;
import com.jdcloud.sdk.service.developer.model.ArticleDetailRequest;
import com.jdcloud.sdk.service.developer.model.ArticleDetailResponse;
import com.jdcloud.sdk.service.portal.client.PortalClient;
import com.jdcloud.sdk.service.portal.model.*;
import org.junit.Test;

import java.util.ArrayList;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/12/6 15:04
 * @Email:huangtiande@jd.com
 */
public class DeveloperClientTest {

    private static DeveloperClient developerClient;

    static {

        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();

        developerClient = DeveloperClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        developerClient.setCustomHeader("x-jdcloud-pin", "jcloud_jRHaaPi");
    }

    @Test
    public void request() {
        ArticleDetailRequest request = new ArticleDetailRequest();
        request.setId(4);
        request.setRegionId("cn-north-1articleDetailTest");
        ArticleDetailResponse response = developerClient.articleDetail(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void articleList() {

    }
}
