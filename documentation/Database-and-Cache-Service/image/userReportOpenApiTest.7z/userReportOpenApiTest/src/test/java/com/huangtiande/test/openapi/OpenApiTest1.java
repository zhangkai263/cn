package com.huangtiande.test.openapi;

import com.jdcloud.sdk.auth.CredentialsProvider;
import com.jdcloud.sdk.auth.StaticCredentialsProvider;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.user.client.UserClient;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/8/26 20:50
 * @Email:huangtiande@jd.com
 */
public class OpenApiTest1 {

    /*********************************线上环境ak/sk******************************************/
    //设置ak,sk
    private static final String accessKeyId = "";
    private static final String secretAccessKey = "";
    private static final String endpoint = "apigw-internal.cn-north-1.jcloudcs.com";

    private static CredentialsProvider credentialsProvider = new StaticCredentialsProvider(accessKeyId, secretAccessKey);

    private static UserClient userClient;

    static {
        Environment ev = new Environment.Builder()
                .endpoint(endpoint)
                .build();

        userClient = UserClient.builder()
                .credentialsProvider(credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build()) //使用HTTP
                .environment(ev)
                .build();

        //记得设置第二个参数pin
        userClient.setCustomHeader("x-jdcloud-pin", "");
    }


    //测试账号报备的openapi
    /*@Test
    public void userReportOpenApiTest(){
        DescribeUserReportRequest request = new DescribeUserReportRequest();
        request.setPin("zhangsan");
        request.setRegionId("huabei");
        DescribeUserReportResponse response = userClient.describeUserReport(request);
        System.out.println(new Gson().toJson(response));
    }*/

    /**pom文件依赖
     *
     *           <dependency>
     *             <groupId>com.jdcloud.sdk</groupId>
     *             <artifactId>core</artifactId>
     *             <version>1.0.8-SNAPSHOT</version>
     *          </dependency>
     *
     *           <dependency>
     *             <groupId>com.jdcloud.sdk</groupId>
     *             <artifactId>user</artifactId>
     *             <version>0.1.4-SNAPSHOT</version>
     *         </dependency>
     *
     *
     *
     * */

}
