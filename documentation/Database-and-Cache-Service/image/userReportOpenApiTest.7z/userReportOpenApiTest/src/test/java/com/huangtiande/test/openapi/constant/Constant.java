package com.huangtiande.test.openapi.constant;

import com.jdcloud.sdk.auth.CredentialsProvider;
import com.jdcloud.sdk.auth.StaticCredentialsProvider;
import com.jdcloud.sdk.service.resourcecenter.model.DescribeNameAndCodeRequest;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/11/6 10:52
 * @Email:huangtiande@jd.com
 */
public class Constant {

    //1. 设置accessKey和secretKey
    /*********************************开发环境*****************************************/
//    public static final String endpoint = "192.168.182.82:8000";
//    public static final String accessKeyId = "636B856DCF14D467D313CCB0C0E2B21C";
//    public static final String secretAccessKey = "6EA0C4C1FC1AD060568A1C117E5C0287";

    /*********************************测试环境 控制台系统ak/sk**************************************/
//    public static final String endpoint = "10.226.145.66:8000";
//    public static final String endpoint = "10.226.148.226:8000";
//    public static final String endpoint = "10.226.144.222:8000";
//    public static final String accessKeyId = "DD1B0BFA7BAA5DAED057ACF4817AF55B";
//    public static final String secretAccessKey = "6FC47989E4F4B1F489004F12FFFD89DE";


    /*********************************测试环境 主账号**************************************/
//    public static final String endpoint = "10.226.145.66:8000";
//    public static final String endpoint = "10.226.148.226:8000";
//    public static final String accessKeyId = "A4EAB793BECEAC87A1E3C4FA09B51D84";
//    public static final String secretAccessKey = "5824634574DF82FCFE330B9CBCC5F302";

    /**********************************测试环境 子账号************************************/
//    public static final String endpoint = "10.226.148.63:8000";
//    public static final String accessKeyId = "FEF1F547DF253AE69C8B8C768C6D2D60";
//    public static final String secretAccessKey = "1E11FB3267A1CE20B829C79C055B94FC";


    /**********************************华东预发二期用户ak/sk**************************/
//    public static final String accessKeyId = "2A35DC46E1BF6977EA548909BB27B2A4";// for test
//    public static final String secretAccessKey = "94AD12FFA01AACB7D358550713DEA4A8";
//    public static final String endpoint = "10.226.200.67:8000";
//    public static final String accessKeyId = "E364C1C6B0B2DADE6C7A8B876FC0B0BD";// for test
//    public static final String secretAccessKey = "BB824882BC74094B3580750D6468C4DB";
//    public static final String endpoint = "10.226.200.67:8000";
//    public static final String endpoint = "apigw-stag.openapi.jdcloud.com";


    /**************************预发二期服务ak/sk******************************************/
//    public static final String accessKeyId = "2A35DC46E1BF6977EA548909BB27B2A4";// for test
//    public static final String secretAccessKey = "94AD12FFA01AACB7D358550713DEA4A8 ";
//    public static final String endpoint = "10.226.200.67:8000";

    /**********************************华东预发二期子账号*******************************/
//    public static final String accessKeyId = "DCF12A92F7A565C477B95C94F25BD0BA";// for test
//    public static final String secretAccessKey = "73CC7822ADA41D6292391B71815EFBD4";
//    public static final String endpoint = "10.226.200.67:8000";//host :10.226.202.225 apigw-stag.openapi.jdcloud.com

    /*******************************预发二期控制台ak/sk**************************************/
//    public static final String accessKeyId = "DD1B0BFA7BAA5DAED057ACF4817AF55B";
//    public static final String secretAccessKey = "6FC47989E4F4B1F489004F12FFFD89DE";
//    public static final String endpoint = "10.226.200.67:8000";
//    public static final String endpoint = "10.226.200.67:8000";
    public static final String accessKeyId = "016EE6947CDDB725F2E692DD4AF76A07";
    public static final String secretAccessKey = "367BE998A060849C7F748B49636CE5AD";
    public static final String endpoint = "apigw-stag.openapi.jdcloud.com";

    /**********************************manage-uc**************************************/
//    public static String accessKeyId = "F5CB6F6F4ACB721C442549302798852D";
//    public static String secretAccessKey = "FB77539DF360BA67052F28E95A711A10";
//    public static final String endpoint = "10.226.200.67:8000";

    /***************************************铸清的****************************************************/
//    public static String accessKeyId = "BFC4016E017385B12174CB6B06AD3C4F";
//    public static String secretAccessKey = "1D2124CCAC8B29B44473F9EBCF88DBB0";
//    public static final String endpoint = "10.226.200.67:8000";

    /*********************************线上环境个人ak/sk******************************************/
//    public static final String accessKeyId = "97327768124B1D8AD2B9272483446095";
//    public static final String secretAccessKey = "86B060FC237C9FB7289121B6AFE32DE1";
//    public static final String endpoint = "apigw-internal.cn-north-1.jcloudcs.com";

    /*********************************线上环境控制台ak/sk******************************************/
//    public static final String accessKeyId = "3778A7BA996B63369B457675DDE9A41B";
//    public static final String secretAccessKey = "39E1E11836286DC208AD770340DA2BEE";
//    public static final String endpoint = "apigw-internal.cn-north-1.jcloudcs.com";

    public static CredentialsProvider credentialsProvider = new StaticCredentialsProvider(accessKeyId, secretAccessKey);
    //todo
    //fixme
}
