package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.resourcecenter.client.ResourcecenterClient;
import com.jdcloud.sdk.service.resourcecenter.model.*;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @Description:
 * @author:huangtiande
 * @date:2019/11/6 11:00
 * @Email:huangtiande@jd.com
 */
public class ResourceCenterClientTest {

    private Logger logger = LoggerFactory.getLogger(ResourceCenterClientTest.class);

    private static ResourcecenterClient resourcecenterClient;

    static {
        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();


        resourcecenterClient = ResourcecenterClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build())
                .environment(ev).build();
        resourcecenterClient.setCustomHeader("x-jdcloud-pin", "nanren311");
    }

    @Test
    public void describeNameAndCodeTest(){
        DescribeNameAndCodeRequest request = new DescribeNameAndCodeRequest();
        request.setRegionId("cn-north-1");
//        request.setName("测试产品线");
        DescribeNameAndCodeResponse response = resourcecenterClient.describeNameAndCode(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getConfigPropertyTest(){
        GetConfigPropertyRequest request = new GetConfigPropertyRequest();
        request.setRegionId("cn-north-1");
        request.setServiceId(423);
        GetConfigPropertyResponse response = resourcecenterClient.getConfigProperty(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getNameAndCodeTest(){
        GetNameAndCodeRequest request = new GetNameAndCodeRequest();
        request.setRegionId("cn-north-1");
        GetNameAndCodeResponse response = resourcecenterClient.getNameAndCode(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeServiceLineTest(){
        DescribeServiceLineRequest request = new DescribeServiceLineRequest();
        request.setRegionId("cn-north-1");
        request.setServiceCode("disk");
        DescribeServiceLineResponse response = resourcecenterClient.describeServiceLine(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getServiceLinePropertyTest() {
        GetServiceLinePropertyRequest request = new GetServiceLinePropertyRequest();
        request.setRegionId("cn-north-1");
        request.setServiceId(1);
        GetServiceLinePropertyResponse response = resourcecenterClient.getServiceLineProperty(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void getRegionAndAzDetailTest(){
        GetRegionAndAzDetailRequest request = new GetRegionAndAzDetailRequest();
        request.setRegionId("cn-north-1");
        request.setId(12);
        GetRegionAndAzDetailResponse response = resourcecenterClient.getRegionAndAzDetail(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getPublishPropertyTest(){
        GetPublishPropertyRequest request = new GetPublishPropertyRequest();
        request.setRegionId("cn-north-1");
        request.setServiceId(422);
        GetPublishPropertyResponse response = resourcecenterClient.getPublishProperty(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getServiceLineTest(){
        GetServiceLineRequest request = new GetServiceLineRequest();
        request.setRegionId("cn-north-1");
        GetServiceLineResponse response = resourcecenterClient.getServiceLine(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void queryServiceLineTest(){
        QueryServiceLineRequest request = new QueryServiceLineRequest();
        request.setRegionId("cn-north-1");
        request.setServiceCode("vm");
        QueryServiceLineResponse response = resourcecenterClient.queryServiceLine(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void queryServiceLinePropertyNameTest(){
        QueryServiceLinePropertyNameRequest request = new QueryServiceLinePropertyNameRequest();
        request.setRegionId("cn-north-1");
        request.setServiceId(299);
        request.setType(1);
        QueryServiceLinePropertyNameResponse response = resourcecenterClient.queryServiceLinePropertyName(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getRegionAndAzListTest(){
        GetRegionAndAzListRequest request = new GetRegionAndAzListRequest();
        request.setRegionId("cn-north-1");
        GetRegionAndAzListResponse response = resourcecenterClient.getRegionAndAzList(request);
        System.out.println(new Gson().toJson(response));
    }


}
