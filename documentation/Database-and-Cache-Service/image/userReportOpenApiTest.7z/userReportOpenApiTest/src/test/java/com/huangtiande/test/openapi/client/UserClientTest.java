package com.huangtiande.test.openapi.client;

import com.google.gson.Gson;
import com.huangtiande.test.openapi.constant.Constant;
import com.jd.common.security.MD5;
import com.jdcloud.sdk.client.Environment;
import com.jdcloud.sdk.http.HttpRequestConfig;
import com.jdcloud.sdk.http.Protocol;
import com.jdcloud.sdk.service.user.client.UserClient;
import com.jdcloud.sdk.service.user.model.*;
import org.junit.Test;


/**
 * @Description:
 * @author:huangtiande
 * @date:2019/11/6 10:55
 * @Email:huangtiande@jd.com
 */
public class UserClientTest {

    private static UserClient userClient;

    static {
        Environment ev = new Environment.Builder()
                .endpoint(Constant.endpoint)
                .build();


        userClient = UserClient.builder()
                .credentialsProvider(Constant.credentialsProvider)
                .httpRequestConfig(new HttpRequestConfig.Builder().protocol(Protocol.HTTP).build()) //使用HTTP
                .environment(ev)
                .build();
        userClient.setCustomHeader("x-jdcloud-pin", "业务研发Jdcloud_02");
    }

    @Test
    public void userReportOpenApiTest(){
        /*DescribeUserInfoForGroupRequest request = new DescribeUserInfoForGroupRequest();
        request.setPin("wwjtest");
        request.setRegionId("cn-north-1");
        DescribeUserInfoForGroupResponse response = userClient.describeUserInfoForGroup(request);
        System.out.println(new Gson().toJson(response));*/
    }

    @Test
    public void describeUserReportTest(){
        DescribeUserReportRequest request = new DescribeUserReportRequest();
        request.setPin("lora1101");
        request.setRegionId("cn-north-1");
        DescribeUserReportResponse response = userClient.describeUserReport(request);
        System.out.println(new Gson().toJson(response));
    }


    @Test
    public void getPinsTest(){
        DescribePinsRequest request = new DescribePinsRequest();
        request.setAffiliation("外部");
        request.setCurrentPage(1);
        request.setPageSize(2);
        request.setRegionId("cn-north-1");
        DescribePinsResponse response = userClient.describePins(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void getUserReportPropertyTest(){
        DescribeUserReportPropertyRequest reportPropertyRequest = new DescribeUserReportPropertyRequest();
        reportPropertyRequest.setPin("jcloud_mgBukny");
//        reportPropertyRequest.setPin("huangyichun0018");
//        reportPropertyRequest.setPin("zhangsan");
        reportPropertyRequest.setRegionId("cn-north-1");
        DescribeUserReportPropertyResponse reportResponse = userClient.describeUserReportProperty(reportPropertyRequest);
        System.out.println(new Gson().toJson(reportResponse));
    }

    @Test
    public void getUserSellerTest(){
        DescribeUserSellerRequest request = new DescribeUserSellerRequest();
        request.setPin("ecop-186");
//        request.setPin("");
        request.setRegionId("cn-north-1");
        DescribeUserSellerResponse response = userClient.describeUserSeller(request);
        System.out.println(new Gson().toJson(response));

    }

    @Test
    public void describeAzMappingTest(){
        DescribeAzMappingRequest request = new DescribeAzMappingRequest();
        request.setKey("azMapping");
        request.setPin("ecop-131");
        request.setRegionId("cn-north-1");
        DescribeAzMappingResponse response = userClient.describeAzMapping(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeUserResourceTypeTest(){
        DescribeUserResourceTypeRequest request = new DescribeUserResourceTypeRequest();
        request.setRegionId("cn-north-1");
        userClient.setCustomHeader("x-jdcloud-pin","huangyichun0018");
        DescribeUserResourceTypeResponse response = userClient.describeUserResourceType(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void isGrayTest(){
        DescribeGrayUserRequest request = new DescribeGrayUserRequest();
        request.setRegionId("cn-north-1");
        request.setPin("业务研发Jdcloud_02");
        request.setServiceCode("DirectoryService");
        DescribeGrayUserResponse response = userClient.describeGrayUser(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeBindPinsTest(){
        DescribeBindPinsRequest request = new DescribeBindPinsRequest();
        request.setRegionId("cn-north-1");
        request.setErp("huangtiande");
        String currentTimeStamp = System.currentTimeMillis()+"";
        String systemName = "jcloudusercenter";
        String systemSecret = "de7f1cf0-3994-4528-bb5d-c26d8651c613";
        request.setTimestamp(currentTimeStamp);
        request.setSignature(new MD5().getMD5ofStr(systemName+systemSecret+currentTimeStamp).toLowerCase());
        DescribeBindPinsResponse response = userClient.describeBindPins(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void describeChildOrganizations(){
        DescribeChildOrganizationsRequest request = new DescribeChildOrganizationsRequest();
        request.setRegionId("cn-north-1");
        request.setParentOrgCode("00065333");
        DescribeChildOrganizationsResponse response = userClient.describeChildOrganizations(request);
        System.out.println(new Gson().toJson(response));
    }

    @Test
    public void modifyContactsTest(){
        ModifyContactsRequest request = new ModifyContactsRequest();
        TransReqVo transReqVo = new TransReqVo();
        transReqVo.setItemId("");
        transReqVo.setItemName("");
        transReqVo.setSourceErp("huangtiande");
        transReqVo.setTargetErp("huangyichun1");
        String currentTimeStamp = System.currentTimeMillis()+"";
        String systemName = "jcloudusercenter";
        String systemSecret = "de7f1cf0-3994-4528-bb5d-c26d8651c613";
        transReqVo.setTimestamp(currentTimeStamp);
        transReqVo.setSignature(new MD5().getMD5ofStr(systemName+systemSecret+currentTimeStamp).toLowerCase());
        request.setTransReqVo(transReqVo);
        request.setRegionId("cn-north-1");
        ModifyContactsResponse response = userClient.modifyContacts(request);
        System.out.println(new Gson().toJson(response));
    }


    @Test
    public void test(){
        int a = 200;
        long b = 200L;
        if (a == b) {
            System.out.println(true);
        }else {
            System.out.println(false);
        }

    }


}
